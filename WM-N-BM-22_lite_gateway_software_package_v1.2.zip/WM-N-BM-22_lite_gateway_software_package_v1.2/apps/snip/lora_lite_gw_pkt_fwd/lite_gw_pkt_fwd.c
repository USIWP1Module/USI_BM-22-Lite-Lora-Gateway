
#include <math.h>
#include "wiced.h"
#include "lite_gw_pkt_fwd.h"
#include "slgw_lib.h"
#include "rf_chain_conf.h"
#include "legacy_pkt_fwd.h"
#include "dlink_json_parser.h"
#include "log_tracer.h"
#include "lite_gw_web.h"
#include "activity_db.h"
#include "gw_status_indicator.h"
#include "gw_sw_reset.h"
#include "gw_dct.h"
#include "lora_str_util.h"

/******************************************************
 *                      Macros
 ******************************************************/
/* */


#define RECONFIG_BUTTON_TIME 5000


#define LOCAL_GW_APPLICATIONS

#define ENABLE_ACTIVITY_RECORD
#define TX_TICK_BY_HOST


#define MSG_DEBUG log_tracer_msg_handler
#define MSG_ERROR log_tracer_msg_handler
#define MSG_INFO  log_tracer_msg_handler

#define DISABLE_NETWORKING

#define Sleep  wiced_rtos_delay_milliseconds

#define NB_PKT_MAX  8


/******************************************************
 *                    Constants
 ******************************************************/


/******************************************************
 *                   Enumerations
 ******************************************************/


/******************************************************
 *                 Type Definitions
 ******************************************************/


/******************************************************
 *                    Structures
 ******************************************************/


/******************************************************
 *               Static Function Declarations
 ******************************************************/


/******************************************************
 *               Variable Definitions
 ******************************************************/
struct lgw_pkt_rx_s rxpkt[NB_PKT_MAX]; /* array containing inbound packets + metadata */

static pgw_app_dct_t gw_app_dct;    /* pointer to the DCT */



/******************************************************
 *               Function Definitions
 ******************************************************/
extern wiced_result_t gw_configure_device(const configuration_entry_t* config, wiced_bool_t forced_config );

wiced_result_t start_packet_forwarder( void );


void application_start( void )
{
    int nb_pkt;
	struct lgw_pkt_tx_s txpkt; /* array containing 1 outbound packet + metadata */


    wiced_init( );

    if( (gw_app_dct = init_gw_dct()) == NULL ){
    	WPRINT_APP_INFO(("found invalid dct!\r\n"));
    }

    print_gw_dct();

    /* initial the indicator and its handler */
    init_gw_status_indicator_handler( WICED_GPIO_16, GW_STATUS_NONE );

    /* pull-high the LORA_SYNC */
    wiced_gpio_init(  WICED_GPIO_6, OUTPUT_PUSH_PULL );
    wiced_gpio_output_high( WICED_GPIO_6 );

    /* pull-low the BT_REG */
    wiced_gpio_init(  WICED_GPIO_22, INPUT_PULL_DOWN );

    /* register RF chain (SM-42 modules) */
	slgw_add_rf_chain( &receiver1_conf );
	slgw_add_rf_chain( &receiver2_conf );
	slgw_add_rf_chain( &receiver3_conf );
	slgw_add_rf_chain( &transmitter_conf );

    /* initial the reset button and its handler */
	init_software_reset_button( WICED_GPIO_17, NULL  );

    /* Configure the device */
	if( is_configure_activated(RECONFIG_BUTTON_TIME) ) gw_configure_device( NULL, WICED_TRUE );
	else gw_configure_device( NULL, WICED_FALSE );

    /* not supported yet */
#if defined( LOCAL_GW_APPLICATIONS )
    /* prepare the gateway portal on the device */
    init_lite_gw_web( gw_app_dct );
#endif

    /* Disable roaming to other access points */
    wiced_wifi_set_roam_trigger( -99 ); /* -99dBm ie. extremely low signal level */

    /* Bringup the network interface */
    wiced_network_up( WICED_STA_INTERFACE, WICED_USE_EXTERNAL_DHCP_SERVER, NULL );

    /* enable to forward debug log on UDP port */
    log_trace_enable_udp( WICED_STA_INTERFACE, 50007 );

    /* not supported yet */
#if defined( LOCAL_GW_APPLICATIONS )
    /* starting up the gateway portal on the device */
    start_lite_gw_web();
#endif

    /* start up the transmitter and receivers */
	lgw_start();

	/* take a delay to avoiding networking thread and platform thread conflict */
	wiced_rtos_delay_milliseconds(10);

    /* establish the connection to remote server for packet forwarding */
	start_packet_forwarder();

	/* loop for forward packets from/to the remote server */
	do  {

		update_gw_indicator();

		/* request the down-link packets and refresh the token from remote server */
		request_pull_legacy_pkt();

		/* check & pull the down-link packets from remote server */
		if( pull_legacy_pkt( &txpkt ) == WICED_SUCCESS ){
			push_to_pkt_db( PKT_GW_DLINK, &txpkt );   /* show the down-link on web */
			lgw_send(txpkt);    /* non-blocking scheduling of TX packet */
		}

		nb_pkt = lgw_receive(1, rxpkt);  /* check if received packets from nodes */

		if (nb_pkt == LGW_HAL_ERROR) {
			MSG_ERROR("ERROR: [up] failed packet fetch, exiting\n");
			continue;
			//exit(EXIT_FAILURE);
		}

		/* wait a short time if no packets, nor status report */
		if ( nb_pkt == 0 ) {
			Sleep(10);
			continue;
		}

		//MSG_DEBUG("receive %d pkts\r\n", nb_pkt);

		push_legacy_pkt( &rxpkt[0] );
		push_to_pkt_db( PKT_GW_ULINK, &rxpkt[0] ); /* show the up-link on web */


	}while( 1 );

	MSG_DEBUG("INFO: Exiting packet forwarder program\n");

}


wiced_result_t start_packet_forwarder( void )
{
	char id[32];
	int id_len;


	/* if if gw_id in DCT is valid */
	id_len = is_valid_gw_id( gw_app_dct->id );
	if( id_len == 0 ){
		MSG_DEBUG("ERROR: invalid GW_ID or no GW_ID setting\n");
		return WICED_FALSE;
	}

	/* convert the hex gw_id in DCT to character array */
	id_len = hex_str_to_char_array( gw_app_dct->id, id );
	if( id_len == 0 ){
		MSG_DEBUG("ERROR: failed to convert gw_id.\n");
		return WICED_FALSE;
	}

    /* establish the connection to remote server for packet forwarding */
    id_len = init_legacy_pkt_fwd( WICED_STA_INTERFACE,  gw_app_dct->url,  gw_app_dct->ul_port, gw_app_dct->dl_port, 20000, id, id_len );
    if( id_len != 0 ) {
    	MSG_DEBUG("%s(): init packet forward error.\n", __FUNCTION__ );
    	return WICED_ERROR;
    }


    return WICED_SUCCESS;
}

