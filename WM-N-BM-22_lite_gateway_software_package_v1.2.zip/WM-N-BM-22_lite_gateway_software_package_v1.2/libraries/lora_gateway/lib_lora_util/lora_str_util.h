#ifndef __LORA_STR_UTIL_H__
#define __LORA_STR_UTIL_H__



char         *get_coderate_text( uint8_t cr );
char         *get_bandwidth_text( uint8_t bw );
int          is_valid_gw_id( char *id );
int          is_valid_hex_char( char *id );
int          is_valid_hex_char( char *id );
int          hex_str_to_char_array( char *hex_in, char *char_out );



#endif // __LORA_STR_UTIL_H__
