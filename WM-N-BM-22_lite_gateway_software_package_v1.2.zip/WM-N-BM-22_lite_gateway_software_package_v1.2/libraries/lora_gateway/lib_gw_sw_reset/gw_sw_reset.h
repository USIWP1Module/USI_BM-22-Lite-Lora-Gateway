#ifndef __GW_SW_RESET_H__
#define __GW_SW_RESET_H__


typedef wiced_result_t (*on_reboot_callback_t)( void );


wiced_result_t init_software_reset_button( wiced_gpio_t reset_button, on_reboot_callback_t reboot_callback );
wiced_bool_t is_configure_activated( wiced_time_t btn_pressed_time );
void software_reset_handler( void );



#endif // __GW_SW_RESET_H__
