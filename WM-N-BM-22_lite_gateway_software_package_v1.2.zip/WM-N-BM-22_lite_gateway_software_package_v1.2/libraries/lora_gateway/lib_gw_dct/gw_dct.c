#include "wiced.h"
#include "lrm_lib.h"
#include "gw_dct.h"





DEFINE_APP_DCT(gw_app_dct_t)
{
	.size    = sizeof(gw_app_dct_t),
    .id      = REMOTE_GW_ID,
    .url     = PKT_FWD_TARGET_URL,
    .ul_port = PKT_FWD_ULINK_PORT,
    .dl_port = PKT_FWD_DLINK_PORT,
};



extern const gw_app_dct_t _app_dct;
static pgw_app_dct_t gw_app_dct = NULL;



static wiced_bool_t is_gw_dct_valid( pgw_app_dct_t dct );
static uint32_t     get_checksum( pgw_app_dct_t dct );



pgw_app_dct_t init_gw_dct( void )
{
	wiced_result_t result;

    /* get the app-dct section for modifying, any memory allocation required would be done inside wiced_dct_read_lock() */
    wiced_dct_read_lock( (void**) &gw_app_dct, WICED_TRUE, DCT_APP_SECTION, 0, sizeof( gw_app_dct_t ) );

	if( is_gw_dct_valid( gw_app_dct ) ) return gw_app_dct;

	WPRINT_APP_INFO(("found invalid dct!\r\n"));

	/* initial app-dct with the default settings */
	memcpy( (void *)gw_app_dct, (const void *)&_app_dct, sizeof(gw_app_dct_t) );

	if( (result = update_gw_dct()) != WICED_SUCCESS ){
		/* write the code here for your action */
	}

	WPRINT_APP_INFO(("initial dct done!\r\n"));

	return gw_app_dct;
}


wiced_result_t update_gw_dct( void )
{
	wiced_result_t result;

	/* get new checksum */
	gw_app_dct->checksum = get_checksum( gw_app_dct );

	/* update in dct */
	result = wiced_dct_write( (const void*) gw_app_dct, DCT_APP_SECTION, 0, sizeof(gw_app_dct_t) );

	if( result != WICED_SUCCESS ){
		WPRINT_APP_INFO(("failed to update dct! (%d)\r\n", result ));
	}

	return result;
}


static wiced_bool_t is_gw_dct_valid( pgw_app_dct_t dct )
{
	/* if size incorrect! */
	if( dct->size != sizeof(gw_app_dct_t) ) return WICED_FALSE;

	return (dct->checksum == get_checksum( dct ));
}



static uint32_t get_checksum( pgw_app_dct_t dct )
{
	int i, len;
	char *p;
	uint32_t check_sum;


	/* calculate the check sum for check */
	p = (char *)dct;
	check_sum = 0;
	len = sizeof(gw_app_dct_t) - sizeof(dct->checksum);
	for( i = 0; i < len; i++ ) check_sum += (uint32_t)(p[i] & 0xFF);

	return check_sum;
}



void print_gw_dct( void )
{
	if( gw_app_dct == NULL ){
		WPRINT_APP_INFO(( "gw_app_dct is NULL.\r\n"));
	}

	WPRINT_APP_INFO(( "size   =%ld\r\n", gw_app_dct->size));
	WPRINT_APP_INFO(( "id     =%s\r\n", gw_app_dct->id));
	WPRINT_APP_INFO(( "url    =%s\r\n", gw_app_dct->url));
	WPRINT_APP_INFO(( "ul_port=%d\r\n", gw_app_dct->ul_port));
	WPRINT_APP_INFO(( "dl_port=%d\r\n", gw_app_dct->dl_port));
	WPRINT_APP_INFO(( "chksum =%ld\r\n", gw_app_dct->checksum));

}
