#ifndef __GW_DCT_H__
#define __GW_DCT_H__



pgw_app_dct_t  init_gw_dct( void );
wiced_result_t update_gw_dct( void );
void           print_gw_dct( void );

#endif // __GW_DCT_H__
