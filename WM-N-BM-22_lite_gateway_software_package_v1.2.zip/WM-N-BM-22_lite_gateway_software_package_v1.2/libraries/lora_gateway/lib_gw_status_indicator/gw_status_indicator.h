#ifndef __GW_STATUS_INDOCATOR_H__
#define __GW_STATUS_INDOCATOR_H__

typedef enum{

	GW_STATUS_NONE,
	GW_STATUS_CONFIG,
	GW_STATUS_REBOOT,
	GW_STATUS_CONNECTED,
	GW_STATUS_DISCONNECTED,
	GW_STATUS_DATA,
	GW_STATUS_RESET,
	GW_STATUS_MAX,
}gw_indicator_status_t;


wiced_result_t init_gw_status_indicator_handler( wiced_gpio_t indicator_gpio, gw_indicator_status_t default_status );
wiced_result_t set_gw_indicator_status( gw_indicator_status_t status );
void set_gw_indicator_on( wiced_bool_t enabled );
//wiced_result_t update_gw_indicator( void );
void update_gw_indicator( void );

#endif // __GW_STATUS_INDOCATOR_H__
