#ifndef __LOG_TRACER_H__
#define __LOG_TRACER_H__


#define HTML_LF "<br />"

/*
#define MSG_ERROR  log_tracer_msg_handler
#define MSG_INFO   log_tracer_msg_handler
#define MSG_DEBUG  log_tracer_msg_handler
*/


void log_tracer_msg_handler( const char *fmt, ... );
void log_tracer_hex_dump( const char *title, const uint8_t *data, int len );
void log_tracer_register_ring_buffer( wiced_ring_buffer_t *ring_buffer );
void log_tracer_init(  void  );
void log_trace_enable_udp(  int interface, int udp_port );






#endif // __LOG_TRACER_H__
