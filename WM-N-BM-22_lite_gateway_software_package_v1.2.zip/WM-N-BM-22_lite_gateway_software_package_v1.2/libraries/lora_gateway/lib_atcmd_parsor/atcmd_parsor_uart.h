#ifndef __UART_H__
#define __UART_H__

#include "atcmd_parsor_def.h"






wiced_result_t atcmd_init_uart( atcmd_console_t *pconsole );
int atcmd_uart_write( atcmd_console_t *pconsole, uint8_t *data, int len );



#endif // __UART_H__
