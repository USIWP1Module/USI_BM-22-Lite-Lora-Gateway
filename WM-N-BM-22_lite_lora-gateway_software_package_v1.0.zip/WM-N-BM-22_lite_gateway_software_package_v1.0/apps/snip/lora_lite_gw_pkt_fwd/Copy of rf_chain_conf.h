#ifndef __RF_CHAIN_CONF_H__
#define __RF_CHAIN_CONF_H__


/* -----------------------------------------------------------------------------------------------------------------
 * the cmd-parsor will use the default memory configuration in 'libraries/lib_atcmd_parsor/atcmd_parsor_def.h',
 * or you can specified your memory configuration by follow the following example.
 *
#define CMD_BUFFER_SIZE     128
#define UART_RX_BUFFER_SIZE 128
#define UART_TX_BUFFER_SIZE 128

static char chain1_uart_rx_buffer[UART_RX_BUFFER_SIZE];
static char chain1_uart_tx_buffer[UART_RX_BUFFER_SIZE];
static char chain1_cmd_buffer[CMD_BUFFER_SIZE];
static char chain1_cmd_resp_buffer[UART_RX_BUFFER_SIZE];
 -------------------------------------------------------------------------------------------------------------------
 */

/* -----------------------------------------------------------------------------------------------------------------
 * the cmd-parsor will use the default UART configuration in 'libraries/lib_atcmd_parsor/atcmd_parsor_def.h',
 * or you can customize an UART configuration by follow the following example, and use it in the following RF-chain definition.
 *
static wiced_uart_config_t sm42_uart_config = {
    .baud_rate = 230400,
    .data_width = DATA_WIDTH_8BIT,
    .parity = NO_PARITY,
    .stop_bits = STOP_BITS_1,
    .flow_control = FLOW_CONTROL_DISABLED,
};
 -------------------------------------------------------------------------------------------------------------------
 */


/*
 * the RF receiver configuration for listens data at Frequency 868.1Mhz
 */
static lrm_conf_t receiver1_conf = {

		/* console configuration (use for AT-CMD communications)*/
		.cmd_console = {

				.if_conf = {

						.port_id = (int)WICED_UART_4,   /* the UART port connected to the receiver (SM-42) */

						/* ----------------------------------------------------------------------------------------------------------
						 * the cmd-parsor will use the default UART configuration in 'libraries/lib_atcmd_parsor/atcmd_parsor_def.h',
						 * or you can specified the uart configuration by follow the following example.
						 *
						.port_conf = (void *)&sm42_uart_config1,
						-------------------------------------------------------------------------------------------------------------
						 */

						/* ------------------------------------------------------------------------------------------------------------
						 * the cmd-parsor will use the default memory configuration in 'libraries/lib_atcmd_parsor/atcmd_parsor_def.h',
						 * or you can specified your memory configuration by follow the following example.
						 *
						.rx_buff = (uint8_t *)&chain1_uart_rx_buffer,
						.rx_buff_size = UART_RX_BUFFER_SIZE,
						.tx_buff = (uint8_t *)&chain1_uart_tx_buffer,
						.tx_buff_size = UART_TX_BUFFER_SIZE,
						----------------------------------------------------------------------------------------------------------------
						 */
				},

				/* -----------------------------------------------------------------------------------------------------------------------------------------------
				 * the cmd-parsor will allocate some memory buffer by follow the memory configurations defined in 'libraries/lib_atcmd_parsor/atcmd_parsor_def.h',
				 * or you can specified the memory buffer with static memory buffer if you need a different memory configuration.
				 *
				.buff_size = CMD_BUFFER_SIZE,
				.buff = chain1_cmd_buffer,
				.buff_length = 0,
				.resp_lines = {
						.entire_buf = {
								.size = UART_RX_BUFFER_SIZE,
								.buf = (char *)chain1_cmd_resp_buffer,
								.len = 0,
						},
				}
				----------------------------------------------------------------------------------------------------------------------------------------------------
				 */
		},

		/* general RF chain configuration */
		.rf_conf = {
				.enable = 1,
				.freq_hz = 868100000,    // the frequency that the module listens
				.rssi_offset = 0,
				.tx_enable = 0,          // use for RX in default
		},

		/* ---------------------------------------------------------------------------------------------------------------------------
		 * the default RF configuration for receiver and transmitter was defined in 'libraries/lib_atcmd_parsor/atcmd_parsor_def.h',
		 * you can override the configurations by the following example
		 *
		.op_mode = LRM_RX_MODE,          // the modem's operation mode
		.dr = (LRM_SF_9 << 16) | (LRM_BW_125K << 8) | LRM_CR_4_5,  // the data rate of TX: DR3 (SF9, BW125, CR)
		.power_dbm = 20,
		.inverted_iq = 0,
		------------------------------------------------------------------------------------------------------------------------------
         */

		.sync_gpio = -1,   // no need to sync the TX/RX timing at this moment. */

};


/*
 * the RF receiver configuration for 868.3Mhz
 * you can override the configuration by follow the examples in the previous 'lrm_conf_t receiver1_conf'
 */
static lrm_conf_t receiver2_conf = {

		/* console configuration (use for AT-CMD communications)*/
		.cmd_console = {
				.if_conf = {
						.port_id = (int)WICED_UART_3,  /* the UART port connected to the receiver (SM-42) */
				},
		},

		/* general RF chain configuration */
		.rf_conf = {
				.enable = 1,
				.freq_hz = 868300000,    // the frequency that we want the module listens
				.rssi_offset = 0,
				.tx_enable = 0,          // use the module as a receiver
		},

		.sync_gpio = -1,   // no need to sync the TX/RX timing at this moment. */
};



/*
 * the RF receiver configuration for 868.5Mhz
 * you can override the configuration by follow the examples in the previous 'lrm_conf_t receiver1_conf'
 */
static lrm_conf_t receiver3_conf = {

		/* console configuration (use for AT-CMD communications)*/
		.cmd_console = {
				.if_conf = {
						.port_id = (int)WICED_UART_1,  /* the UART port connected to the receiver (SM-42) */
				},
		},

		/* general RF chain configuration */
		.rf_conf = {
				.enable = 1,
				.freq_hz = 868500000,    // the frequency that we want the module listens
				.rssi_offset = 0,
				.tx_enable = 0,          // use the module as a receiver
		},

		.sync_gpio = -1,   // no need to sync the TX/RX timing at this moment. */
};



static lrm_conf_t transmitter_conf = {

		/* console configuration (use for AT-CMD communications)*/
		.cmd_console = {

				.if_conf = {
						.port_id = (int)WICED_UART_2,   /* the UART port connected to the transmitter (SM-42) */
				},
		},

		/* general RF chain configuration */
		.rf_conf = {
				.enable = 1,
				.freq_hz = 869525000,  // the frequency that we want to use for TX
				.rssi_offset = 0,
				.tx_enable = 1,    // use the module as a transmitter

		},

		.sync_gpio = WICED_GPIO_30,  // raising the GPIO to triggering the TX on RX1 or RX2
};



#endif  // __RF_CHAIN_CONF_H__


