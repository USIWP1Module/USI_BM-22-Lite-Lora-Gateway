
#include "lite_gw_pkt_fwd.h"
#include <math.h>
#include "wiced.h"
#include "slgw_lib.h"
#include "rf_chain_conf.h"
#include "legacy_pkt_fwd.h"
#include "dlink_json_parser.h"
#include "log_tracer.h"
#include "lite_gw_web.h"
#include "activity_db.h"


/******************************************************
 *                      Macros
 ******************************************************/
/* */

#if 1
#define PKT_FWD_TARGET_URL  "router.eu.thethings.network"
#define PKT_FWD_DLINK_PORT   1700
#define PKT_FWD_ULINK_PORT   1700
#endif

#if 0
#define PKT_FWD_TARGET_URL  "192.168.11.7"
#define PKT_FWD_DLINK_PORT   1680
#define PKT_FWD_ULINK_PORT   1680
#endif

#define LOCAL_GW_APPLICATIONS

#define ENABLE_ACTIVITY_RECORD
#define TX_TICK_BY_HOST

#define MSG_DEBUG log_tracer_msg_handler
#define MSG_ERROR log_tracer_msg_handler
#define MSG_INFO  log_tracer_msg_handler

#define DISABLE_NETWORKING

#define Sleep  wiced_rtos_delay_milliseconds

#define NB_PKT_MAX  8


/******************************************************
 *                    Constants
 ******************************************************/


/******************************************************
 *                   Enumerations
 ******************************************************/


/******************************************************
 *                 Type Definitions
 ******************************************************/


/******************************************************
 *                    Structures
 ******************************************************/


/******************************************************
 *               Static Function Declarations
 ******************************************************/


/******************************************************
 *               Variable Definitions
 ******************************************************/
struct lgw_pkt_rx_s rxpkt[NB_PKT_MAX]; /* array containing inbound packets + metadata */




/******************************************************
 *               Function Definitions
 ******************************************************/


void application_start( void )
{
    int nb_pkt;
	struct lgw_pkt_tx_s txpkt; /* array containing 1 outbound packet + metadata */

    wiced_init( );

    wiced_gpio_init(  WICED_GPIO_6, OUTPUT_PUSH_PULL );
    wiced_gpio_output_high( WICED_GPIO_6 );

    wiced_gpio_init(  WICED_GPIO_22, INPUT_PULL_DOWN );
    //wiced_gpio_init(  WICED_GPIO_22, OUTPUT_PUSH_PULL );
    //wiced_gpio_output_low( WICED_GPIO_22 );

    /* register RF chain (SM-42 modules) */
	slgw_add_rf_chain( &receiver1_conf );
	slgw_add_rf_chain( &receiver2_conf );
	slgw_add_rf_chain( &receiver3_conf );
	slgw_add_rf_chain( &transmitter_conf );

    /* Configure the device */
    wiced_configure_device( NULL );

    /* not supported yet */
#if defined( LOCAL_GW_APPLICATIONS )
    /* prepare the gateway portal on the device */
    init_lite_gw_web();
#endif

    /* Disable roaming to other access points */
    wiced_wifi_set_roam_trigger( -99 ); /* -99dBm ie. extremely low signal level */

    /* Bringup the network interface */
    wiced_network_up( WICED_STA_INTERFACE, WICED_USE_EXTERNAL_DHCP_SERVER, NULL );

    /* enable to forward debug log on UDP port */
    log_trace_enable_udp( WICED_STA_INTERFACE, 50007 );

    /* not supported yet */
#if defined( LOCAL_GW_APPLICATIONS )
    /* starting up the gateway portal on the device */
    start_lite_gw_web();
#endif


    /* start up the transmitter and receivers */
	lgw_start();

    /* establish the connection to remote server for packet forwarding */
    init_legacy_pkt_fwd( WICED_STA_INTERFACE,  PKT_FWD_TARGET_URL,  PKT_FWD_DLINK_PORT, PKT_FWD_ULINK_PORT, 20000 );

	/* loop for forward packets from/to the remote server */
	do  {



		/* request the down-link packets and refresh the token from remote server */
		request_pull_legacy_pkt();

		/* check & pull the down-link packets from remote server */
		if( pull_legacy_pkt( &txpkt ) == WICED_SUCCESS ){
			push_to_pkt_db( PKT_GW_DLINK, &txpkt );   /* show the down-link on web */
			lgw_send(txpkt);    /* non-blocking scheduling of TX packet */
		}

		nb_pkt = lgw_receive(1, rxpkt);  /* check if received packets from nodes */

		if (nb_pkt == LGW_HAL_ERROR) {
			MSG_ERROR("ERROR: [up] failed packet fetch, exiting\n");
			continue;
			//exit(EXIT_FAILURE);
		}

		/* wait a short time if no packets, nor status report */
		if ( nb_pkt == 0 ) {
			Sleep(10);
			continue;
		}

		//MSG_DEBUG("receive %d pkts\r\n", nb_pkt);

		push_legacy_pkt( &rxpkt[0] );
		push_to_pkt_db( PKT_GW_ULINK, &rxpkt[0] ); /* show the up-link on web */


	}while( 1 );

	MSG_DEBUG("INFO: Exiting packet forwarder program\n");

}






