
#ifndef __LEGACY_PKT_PWD_H__
#define __LEGACY_PKT_PWD_H__

#include "loragw_hal.h"


#define THE_GATEWAY_ID "\xFF\xFE\x02\x0A\xF7\x58\x20\x9D"

int init_legacy_pkt_fwd( wiced_interface_t intf,  char *host_ip_text,  uint16_t up_port, uint16_t down_port, wiced_time_t keep_alive_time );
wiced_result_t pull_legacy_pkt( struct lgw_pkt_tx_s *lrtx_pkt );
int request_pull_legacy_pkt( void );
int push_legacy_pkt( struct lgw_pkt_rx_s *p );



#endif    // __LEGACY_PKT_PWD_H__
