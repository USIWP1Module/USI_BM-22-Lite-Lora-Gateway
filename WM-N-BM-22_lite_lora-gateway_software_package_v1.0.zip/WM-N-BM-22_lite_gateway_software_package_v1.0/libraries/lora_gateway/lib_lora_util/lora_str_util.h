#ifndef __LORA_STR_UTIL_H__
#define __LORA_STR_UTIL_H__



char *get_coderate_text( uint8_t cr );
char *get_bandwidth_text( uint8_t bw );



#endif // __LORA_STR_UTIL_H__
