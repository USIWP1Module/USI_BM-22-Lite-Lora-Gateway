#include "wiced.h"
#include "log_tracer.h"
#include <stdarg.h>



typedef struct{

	int interface;
	int port;
	wiced_ip_address_t ip;
	wiced_udp_socket_t socket;
	wiced_bool_t enabled;

}log_trace_udp_t;



static wiced_ring_buffer_t *plog_tracer_ring_buffer = (wiced_ring_buffer_t *)0;
static log_trace_udp_t udp_conf[2];
static uint32_t udp_log_count = 0;
static char the_ip_addr_str[16] = { 0 };


static wiced_result_t log_trace_tx_packet(  int interface, uint8_t *data, int len );


void log_tracer_init(  void  )
{


}




void log_trace_enable_udp(  int interface, int udp_port )
{
	wiced_ip_address_t ip_addr;
	int i;

	if( interface > 1 ) {
		WPRINT_APP_INFO(( "%s(): invalid interface number: %d", __FUNCTION__, interface ));
		return;
	}

	if( udp_conf[interface].enabled ){

		WPRINT_APP_INFO(( "%s(): the udp on intf-%d is enabled already", __FUNCTION__, interface ));
		return;

	}

	udp_conf[interface].port = udp_port;

    wiced_ip_get_ipv4_address(  interface , &ip_addr  );

    memcpy( &udp_conf[interface].ip, &ip_addr, sizeof(wiced_ip_address_t) );

    udp_conf[interface].ip.ip.v4 |= 0xFF;  /* make it as a broadcast address */

    /* Create UDP socket */
    if ( wiced_udp_create_socket( &udp_conf[interface].socket, udp_port, interface) != WICED_SUCCESS )
    {
        WPRINT_APP_INFO( ("%s(): UDP socket creation failed\n", __FUNCTION__ ) );
    }

    udp_conf[interface].enabled = WICED_TRUE;

#if 0
    i = sprintf( the_ip_addr_str, "%ld.%ld.%ld.%ld",
    		(ip_addr.ip.v4 >> 24) & 0xFF,
    		(ip_addr.ip.v4 >> 16) & 0xFF,
    		(ip_addr.ip.v4 >> 8) & 0xFF,
    		ip_addr.ip.v4 & 0xFF
        );
#else
    i = sprintf( the_ip_addr_str, "x.x.x.%ld", ip_addr.ip.v4 & 0xFF  );
#endif

    the_ip_addr_str[i] = 0;

    log_tracer_msg_handler( "start log tracer on %s ...\r\n", the_ip_addr_str );

}





void log_tracer_register_ring_buffer( wiced_ring_buffer_t *ring_buffer )
{
	plog_tracer_ring_buffer = ring_buffer;
}



/*
 * Sends a UDP packet
 */
static wiced_result_t log_trace_tx_packet(  int interface, uint8_t *data, int len )
{
    wiced_packet_t*          packet;
    uint8_t *                udp_data;
    uint16_t                 available_data_length;

    /* Create the UDP packet */
    if ( wiced_packet_create_udp( &udp_conf[interface].socket, len, &packet, (uint8_t**) &udp_data, &available_data_length ) != WICED_SUCCESS )
    {
        WPRINT_APP_INFO( ("%s(): UDP tx packet creation failed for intf-%d\n", __FUNCTION__, interface ));
        return WICED_ERROR;
    }

    memcpy( &udp_data[0], data, len );

    /* Set the end of the data portion */
    wiced_packet_set_data_end( packet, (uint8_t*) (udp_data + len) );

    /* Send the UDP packet */
    if ( wiced_udp_send( &udp_conf[interface].socket, &udp_conf[interface].ip, udp_conf[interface].port, packet ) != WICED_SUCCESS )
    {
        WPRINT_APP_INFO( ("%s(): UDP packet send failed on intf-%d\n", __FUNCTION__, interface ) );
        wiced_packet_delete( packet ); /* Delete packet, since the send failed */
        return WICED_ERROR;
    }

    return WICED_SUCCESS;
}

static char msg_handler_buf[256];

void log_tracer_msg_handler( const char *fmt, ... )
{
	//char buf[256];
    va_list args;
    int len;


    //len = sprintf( msg_handler_buf, "\r\n{%08lX} ", udp_log_count++ );
    len = sprintf( msg_handler_buf, "\r\n{%s::%08lX} ", the_ip_addr_str, udp_log_count++ );

    va_start(args, fmt);
    len += vsnprintf( &msg_handler_buf[len], sizeof(msg_handler_buf) - len, fmt, args);
    va_end(args);

    msg_handler_buf[len] = 0;

    WPRINT_APP_INFO(( msg_handler_buf ));
    /* forward log by udp */
    if( udp_conf[WICED_STA_INTERFACE].enabled ) log_trace_tx_packet( WICED_STA_INTERFACE, (uint8_t *)msg_handler_buf, len );
    if( udp_conf[WICED_AP_INTERFACE].enabled )  log_trace_tx_packet( WICED_AP_INTERFACE, (uint8_t *)msg_handler_buf, len );
    /* forward log to ring buffer */
    if( plog_tracer_ring_buffer ) ring_buffer_write( plog_tracer_ring_buffer, (uint8_t *)msg_handler_buf, len );

}

void log_tracer_hex_dump( const char *title, const uint8_t *data, int len )
{
	char buf[128];
	int len1;
	int i;

	len1 = sprintf( &buf[0], "%s",  title );

	for( i = 0; i < len; i++ ){
		if( len1 >= sizeof(buf) - 3 ) break;  /* reserve for line-feed characters */
		len1 += sprintf( &buf[len1], " %02X", data[i] & 0xFF );
	}

	len1 += sprintf( &buf[len1], "\r\n" );
	buf[len1] = 0;

    WPRINT_APP_INFO(( buf ));

    /* forward log by udp */
    if( udp_conf[WICED_STA_INTERFACE].enabled ) log_trace_tx_packet( WICED_STA_INTERFACE, (uint8_t *)buf, len1 );
    if( udp_conf[WICED_AP_INTERFACE].enabled )  log_trace_tx_packet( WICED_AP_INTERFACE, (uint8_t *)buf, len1 );
    /* forward log to ring buffer */
    if( plog_tracer_ring_buffer ) ring_buffer_write( plog_tracer_ring_buffer, (uint8_t *)buf, len1 );

}

