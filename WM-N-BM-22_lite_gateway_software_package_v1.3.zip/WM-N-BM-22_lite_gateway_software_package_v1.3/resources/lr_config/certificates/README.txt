----------------------------------------------------------
 x.509 Certificates - README
----------------------------------------------------------

WICED currently only supports reading .pem formatted TLS
certificates per http://tools.ietf.org/html/rfc1421