
#ifndef __SLGW_LIB_DEF_H__
#define __SLGW_LIB_DEF_H__


//#include "loragw_hal.h"
//#include "atcmd_parsor.h"


#define MAX_RF_CHAIN_NUMBER  4











#endif // __SLGW_LIB_DEF_H__

