#ifndef __SLGW_LIB_H__
#define __SLGW_LIB_H__


#include "slgw_lib_def.h"
#include "lrm_lib.h"


int slgw_init( void );
int slgw_add_rf_chain( lrm_conf_t *rf_chain );
int slgw_init_rx_ring_buff( int size );
int slgw_push_ring_buff( void *rf_chain, uint8_t *payload, int size, int rssi, int snr, int time_stamp_ms );
void lgw_gen_test_packet( wiced_time_t interval );




#endif   // __SLGW_LIB_H__
