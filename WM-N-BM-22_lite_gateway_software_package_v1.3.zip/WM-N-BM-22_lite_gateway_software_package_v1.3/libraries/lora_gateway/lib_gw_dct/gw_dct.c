#include "wiced.h"
#include "lrm_lib.h"
#include "gw_dct.h"
#include "lora_str_util.h"

#define ERR_MSG_DCT_UPDATE_ERROR    "write dct error!\r\n"
#define ERR_MSG_DCT_UPDATE_DONE     "write dct done!\r\n"
#define ERR_MSG_DCT_INVALID_HEX_STR "new gw_id is invalid hex string\r\n"
#define ERR_MSG_DCT_EMPTY_GW_URL    "gw_url can not empty\r\n"
#define ERR_MSG_DCT_EMPTY_PORT_NUM  "port number cannot empty\r\n"
#define ERR_MSG_DCT_PORT_OUT_RANGE  "port number out of range\r\n"



DEFINE_APP_DCT(gw_app_dct_t)
{
	.size    = sizeof(gw_app_dct_t),
    .id      = REMOTE_GW_ID,
    .url     = PKT_FWD_TARGET_URL,
    .ul_port = PKT_FWD_ULINK_PORT,
    .dl_port = PKT_FWD_DLINK_PORT,
};



extern const gw_app_dct_t _app_dct;
static pgw_app_dct_t gw_app_dct = NULL;



static wiced_bool_t is_gw_dct_valid( pgw_app_dct_t dct );
static uint32_t     get_checksum( pgw_app_dct_t dct );

static wiced_result_t update_pkt_fwd_setting_by_item( char *response_msg, int param_index, char *param, int *written_bytes );



pgw_app_dct_t init_gw_dct( void )
{
	wiced_result_t result;

    /* get the app-dct section for modifying, any memory allocation required would be done inside wiced_dct_read_lock() */
    wiced_dct_read_lock( (void**) &gw_app_dct, WICED_TRUE, DCT_APP_SECTION, 0, sizeof( gw_app_dct_t ) );

	if( is_gw_dct_valid( gw_app_dct ) ) return gw_app_dct;

	WPRINT_APP_INFO(("found invalid dct!\r\n"));

	/* initial app-dct with the default settings */
	memcpy( (void *)gw_app_dct, (const void *)&_app_dct, sizeof(gw_app_dct_t) );

	if( (result = update_gw_dct()) != WICED_SUCCESS ){
		/* write the code here for your action */
	}

	WPRINT_APP_INFO(("initial dct done!\r\n"));

	return gw_app_dct;
}


wiced_result_t update_gw_dct( void )
{
	wiced_result_t result;

	/* get new checksum */
	gw_app_dct->checksum = get_checksum( gw_app_dct );

	/* update in dct */
	result = wiced_dct_write( (const void*) gw_app_dct, DCT_APP_SECTION, 0, sizeof(gw_app_dct_t) );

	if( result != WICED_SUCCESS ){
		WPRINT_APP_INFO(("failed to update dct! (%d)\r\n", result ));
	}

	return result;
}


static wiced_bool_t is_gw_dct_valid( pgw_app_dct_t dct )
{
	/* if size incorrect! */
	if( dct->size != sizeof(gw_app_dct_t) ) return WICED_FALSE;

	return (dct->checksum == get_checksum( dct ));
}



static uint32_t get_checksum( pgw_app_dct_t dct )
{
	int i, len;
	char *p;
	uint32_t check_sum;


	/* calculate the check sum for check */
	p = (char *)dct;
	check_sum = 0;
	len = sizeof(gw_app_dct_t) - sizeof(dct->checksum);
	for( i = 0; i < len; i++ ) check_sum += (uint32_t)(p[i] & 0xFF);

	return check_sum;
}



void print_gw_dct( void )
{
	if( gw_app_dct == NULL ){
		WPRINT_APP_INFO(( "gw_app_dct is NULL.\r\n"));
	}

	WPRINT_APP_INFO(( "size   =%ld\r\n", gw_app_dct->size));
	WPRINT_APP_INFO(( "id     =%s\r\n", gw_app_dct->id));
	WPRINT_APP_INFO(( "url    =%s\r\n", gw_app_dct->url));
	WPRINT_APP_INFO(( "ul_port=%d\r\n", gw_app_dct->ul_port));
	WPRINT_APP_INFO(( "dl_port=%d\r\n", gw_app_dct->dl_port));
	WPRINT_APP_INFO(( "chksum =%ld\r\n", gw_app_dct->checksum));

}



/* this is used by http service for changing the dct settings and returns the result in text */
/* response_buffer: the update result message */
/* url_parameters: setting paramters from http */
/* return: the length of the result message */
int32_t gw_dct_http_handler( char *response_buffer, const char* url_parameters )
{
	int len;
	int param_count;

	/* change request */
    if( url_parameters ) {

    	/* we used the response_buffer for parsing and response, so we must return immediately if the response produced,
    	 * because the responses was in the buffer already and cannot be overwrite.. */

    	WPRINT_APP_INFO(("parameters--> %s\r\n", url_parameters ));

    	param_count = 0;
    	len = 0;

    	while( *url_parameters ){

    		response_buffer[len] = *url_parameters;

    		if( *url_parameters == '&' ){

    			response_buffer[len] = 0;

    			/* return with the message if error */
    			if( update_pkt_fwd_setting_by_item( response_buffer, param_count, response_buffer, &len ) != WICED_SUCCESS ) return len;

    			len = 0;
    			response_buffer[len] = 0;
    			param_count++;

    		}else len++;

			url_parameters++;
    	}  // end of while loop


    	if( len ){
    		response_buffer[len] = 0;
			/* return with the message if error */
			if( update_pkt_fwd_setting_by_item( response_buffer, param_count, response_buffer, &len ) != WICED_SUCCESS ) return len;
    	}


    	/* update in dct, and return the update result */
    	if( update_gw_dct() != WICED_SUCCESS ){
			WPRINT_APP_INFO((ERR_MSG_DCT_UPDATE_ERROR));
			len = sprintf( response_buffer, "%s", ERR_MSG_DCT_UPDATE_ERROR );
			response_buffer[len] = 0;
			//wiced_http_response_stream_write(stream, ERR_MSG_DCT_UPDATE_ERROR, sizeof( ERR_MSG_DCT_UPDATE_ERROR ) -1  );
    	}else{
			WPRINT_APP_INFO((ERR_MSG_DCT_UPDATE_DONE));
			len = sprintf( response_buffer, "%s", ERR_MSG_DCT_UPDATE_DONE );
			response_buffer[len] = 0;
			//wiced_http_response_stream_write(stream, ERR_MSG_DCT_UPDATE_DONE, sizeof( ERR_MSG_DCT_UPDATE_DONE ) -1  );
    	}

    	/* return the update result */
        return len;

    } /* end of the change request */


    /* query current settings */

    len = 0;
	len += sprintf(  &response_buffer[len], "%s", gw_app_dct->id );
	len += sprintf(  &response_buffer[len], "\n%s", gw_app_dct->url );
	len += sprintf(  &response_buffer[len], "\n%d", gw_app_dct->ul_port );
	len += sprintf(  &response_buffer[len], "\n%d", gw_app_dct->dl_port );

	response_buffer[len] = 0; /* terminate string */
	//wiced_tcp_stream_write(stream, web_char_buffer,  len );

	/* end of the query */

   return len;
}



static wiced_result_t update_pkt_fwd_setting_by_item( char *response_msg, int param_index, char *param, int *written_bytes )
{
	wiced_result_t result = WICED_SUCCESS;
	int i;

	*written_bytes = 0;  /* assume no message will be produced */

	switch( param_index ){

	case 0:  /* gw_id */

    	WPRINT_APP_INFO(("parameters-%d: %s\r\n", param_index, param ));

		i = is_valid_gw_id( param );

		if( i == 0 ){
			WPRINT_APP_INFO(( ERR_MSG_DCT_INVALID_HEX_STR ));
			i = sprintf( response_msg, "%s", ERR_MSG_DCT_INVALID_HEX_STR );
			response_msg[i] = 0;
			*written_bytes = i;
			//wiced_http_response_stream_write( stream, ERR_MSG_DCT_INVALID_HEX_STR, sizeof( ERR_MSG_DCT_INVALID_HEX_STR ) -1  );
			return WICED_ERROR;
		}else if( i > GW_ID_MAX_SIZE ){
			i = sprintf( response_msg, "gw_id cannot over %d byte(s).\r\n", GW_ID_MAX_SIZE );
			response_msg[i] = 0;
			*written_bytes = i;
			WPRINT_APP_INFO((response_msg));
			//wiced_http_response_stream_write(stream, web_char_buffer, i );
			return WICED_ERROR;
		}

		memcpy( gw_app_dct->id, param, i );
		gw_app_dct->url[i] = 0;

    	break;

	case 1:  /* gw_url */

    	WPRINT_APP_INFO(("parameters-%d: %s\r\n", param_index, param ));

		i = strlen( param );

		if( i == 0 ){
			i = sprintf( response_msg, ERR_MSG_DCT_EMPTY_GW_URL );
			response_msg[i] = 0;
			*written_bytes = i;
			WPRINT_APP_INFO(( response_msg ));
			//wiced_http_response_stream_write(stream, web_char_buffer, i  );
			return WICED_ERROR;
		}else if( i > GW_URL_MAX_SIZE ){
			i = sprintf( response_msg, "gw_url cannot over %d byte(s).\r\n", GW_URL_MAX_SIZE );
			response_msg[i] = 0;
			*written_bytes = i;
			WPRINT_APP_INFO((response_msg));
			//wiced_http_response_stream_write(stream, web_char_buffer, i );
			return WICED_ERROR;
		}

		memcpy( gw_app_dct->url, param, i );
		gw_app_dct->url[i] = 0;

    	break;

	case 2:   /* gw_up_link */
	case 3:   /* gw_down_link */
    	WPRINT_APP_INFO(("parameters-%d: %s\r\n", param_index, param ));

    	i = strlen(param);

    	if( i <= 0 ){
			i = sprintf( response_msg, ERR_MSG_DCT_EMPTY_PORT_NUM );
			response_msg[i] = 0;
			*written_bytes = i;
			WPRINT_APP_INFO(( response_msg ));
			//wiced_http_response_stream_write(stream, web_char_buffer, i  );
			return WICED_ERROR;
    	}


    	i = atoi( param );

    	if( i <= 0 || i > 65535 ){
			i = sprintf( response_msg, ERR_MSG_DCT_PORT_OUT_RANGE );
			response_msg[i] = 0;
			*written_bytes = i;
			WPRINT_APP_INFO(( response_msg ));
			//wiced_http_response_stream_write(stream, web_char_buffer, i  );
			return WICED_ERROR;
    	}

    	if( param_index == 2 ) gw_app_dct->ul_port = i;
    	if( param_index == 3 ) gw_app_dct->dl_port = i;

    	break;

	default:
		i = sprintf( response_msg, "unknown parameter: %s\r\n", param );
		response_msg[i] = 0;
		*written_bytes = i;
		WPRINT_APP_INFO((response_msg));
		result = WICED_ERROR;

	}


	return result;
}



