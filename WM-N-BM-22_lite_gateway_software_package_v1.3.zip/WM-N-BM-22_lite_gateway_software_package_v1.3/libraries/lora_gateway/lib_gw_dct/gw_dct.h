#ifndef __GW_DCT_H__
#define __GW_DCT_H__



pgw_app_dct_t  init_gw_dct( void );
wiced_result_t update_gw_dct( void );
void           print_gw_dct( void );

int32_t        gw_dct_http_handler( char *response_buffer, const char* url_parameters );

#endif // __GW_DCT_H__
