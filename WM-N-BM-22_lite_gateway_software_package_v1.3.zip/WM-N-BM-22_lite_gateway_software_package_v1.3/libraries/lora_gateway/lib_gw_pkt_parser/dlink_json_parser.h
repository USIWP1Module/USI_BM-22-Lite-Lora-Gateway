#ifndef __DLINK_JSON_PARSER_H__
#define __DLINK_JSON_PARSER_H__


wiced_result_t get_tx_pkt_from_json( char *json,  int json_size, struct lgw_pkt_tx_s *txpkt );






#endif // __DLINK_JSON_PARSER_H__
