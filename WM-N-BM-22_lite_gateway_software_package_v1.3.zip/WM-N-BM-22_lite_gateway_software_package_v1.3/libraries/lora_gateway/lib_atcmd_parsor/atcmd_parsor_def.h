#ifndef __ATCMD_PARSOR_DEF_H__
#define __ATCMD_PARSOR_DEF_H__

#define BUFF_SIZE 2048
#define MAX_ATCMD_NUMBER 100


/* Suppress unused parameter warning */
#ifndef UNUSED_PARAMETER
#define UNUSED_PARAMETER(x) ( (void)(x) )
#endif

/* default UART configuration for the at-command console */
/* the at-cmd parsor will use the default settings to initialize the UART if call atcmd_init_uart() without specified settings. */
#define DEFAULT_UART_BAUD_RATE   230400
#define DEFAULT_UART_DATA_WIDTH  DATA_WIDTH_8BIT
#define DEFAULT_UART_PARITY      NO_PARITY
#define DEFAULT_UART_STOP_BITS   STOP_BITS_1
#define DEFAULT_UART_FLOW_CTRL   FLOW_CONTROL_DISABLED

/* default configuration of memory size for cmd buffers for at-command parsor  */
/* the at-cmd parsor will use the default settings to allocating all required memory used for the at-command buffers if call atcmd_add_console() without specified settings. */
#define DEFAULT_UART_RX_BUFFER_SIZE 128
#define DEFAULT_UART_TX_BUFFER_SIZE 128
#define DEFAULT_CMD_BUFFER_SIZE 128
#define DEFAULT_RESP_BUFFER_SIZE 128


typedef enum {

	ATCMD_IF_UART,
	ATCMD_IF_SPI,

} atcmd_if_types_t ;


typedef struct {

	atcmd_if_types_t if_type;    /* UART or SPI */
	int  port_id;                /* PORT ID on UART or SPI*/
	void *port_conf;             /* UART/SPI CONFIGURATION */
	uint8_t *rx_buff;            /* the RX BUFFER */
	int rx_buff_size;            /* the LENGTH of RX BUFF */
	uint8_t *tx_buff;            /* the RX BUFFER */
	int tx_buff_size;            /* the LENGTH of RX BUFF */
	wiced_ring_buffer_t rx_ring_buff;  /* the RING BUFFER of RX */

}atcmd_if_conf_t;


typedef struct
{
	char *buf;
	int  size;
	int  len;

}atcmd_arg_t;


typedef struct
{
	atcmd_arg_t entire_buf;
	atcmd_arg_t lines[10];
	int line_count;
	int lines_size;

}atcmd_args_t;



typedef struct
{
	uint8_t flags;
	int id;

	atcmd_if_conf_t if_conf;    /* the configuration of interface */

	char *buff;                 /* the queue of command buffer */
    int  buff_size;             /* the size of command buffer (capacity) */
	int  buff_length;           /* the length of data in the command buffer */

	int resp_ok_number;
	int resp_err_number;

    int last_ok_number;
    int last_err_number;

	int last_err_code;

	int err_cmd_retry_count;

	void *tag;

	wiced_bool_t is_keep_all_response;
	atcmd_args_t resp_lines; /* the response buffer for keep the all of responses from the slave device */



}atcmd_console_t;






typedef enum  {
	AT_ERROR_OK,
    AT_ERROR_UNKNOW = -1,
    AT_ERROR_UNKNOW_COMMAND = -2,
	AT_ERROR_LESS_ARGUMENTS = -3,
	AT_ERROR_MORE_ARGUMENETS = -4,
    AT_ERROR_INVALID_ARGUMENTS = -5,
	AT_ERROR_NOT_SUPPORTED = -6,
	AT_ERROR_OUT_OF_RANGE = -7,
	AT_ERROR_RX_TIMEOUT = -8,
	AT_ERROR_RX_ERROR = -9,
	AT_ERROR_TX_TIMEOUT = -10,
	AT_ERROR_TX_ERROR = -11,
	AT_ERROR_RF_BUSY = -12,
	AT_ERROR_TIMEOUT = -13,
	AT_ERROR_NO_ARGUMENETS_NEEDED = -14,
	AT_ERROR_HAL_ERROR = -15,
	AT_ERROR_INVALID_HEX_FORMAT = -16,
    AT_ERROR_OUT_OF_ADDRESS = -17,
	AT_ERROR_INVALID_NVM_TAG = -18,
	AT_ERROR_NVM_FULL = -18,
	AT_ERROR_NVM_TAG_NOT_FOUND = -19,
	AT_ERROR_7SEG_ERROR = -20,
	AT_ERROR_TMP75_ERROR = -21,

	AT_ERROR_WAN_SEND = -100,
	AT_ERROR_WAN_GETPARAM = -101,
	AT_ERROR_WAN_SETPARAM = -102,
	AT_ERROR_WAN_NON_JOINED = -103,

	AT_ERROR_MFG_FUNC_NOT_INITIATED = -9000,	
}error_code_t;

typedef int (*ATCMD_PROCESS)( atcmd_console_t *pconsole, uint8_t **args, int args_count );

typedef struct
{
    ATCMD_PROCESS func;
    uint8_t *response_id;

}response_atcmds_t;



typedef struct
{
    int code;
	uint8_t *verbose_text;
}code_info_t;

typedef void (*TX_DONE_CALL_BACK)( void );
typedef void (*RX_DONE_CALL_BACK)( uint8_t* text );






#endif // __ATCMD_PARSOR_DEF_H__
