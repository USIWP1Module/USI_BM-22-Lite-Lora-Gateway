#ifndef __STR_UTL_H__
#define __STR_UTL_H__


uint8_t *ToLower( uint8_t *str );
uint8_t *ToUpper( uint8_t *str );

int      ToInt( uint8_t *data, int default_value );
int      StrCmp( uint8_t *src, uint8_t *dst );
int     IsStrContains( uint8_t *src, uint8_t *pattern );
int     IsStrContain( uint8_t *str, uint8_t c );
int      GetValidHexLen( uint8_t  *str );
uint8_t  WideHexCharToInt( uint8_t *c );
void     CeonvertHexChar( uint8_t *dst, uint8_t *hex, int len );
uint32_t GetChecksum( uint8_t *data, int len );

#endif // __STR_UTL_H__

