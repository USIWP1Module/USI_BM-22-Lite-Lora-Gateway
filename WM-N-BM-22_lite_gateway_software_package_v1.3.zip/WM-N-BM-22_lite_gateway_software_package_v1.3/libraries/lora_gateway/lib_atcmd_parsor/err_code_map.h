#ifndef __ERR_CODE_MAP_H__
#define __ERR_CODE_MAP_H__



// error code vs error description table

code_info_t rola_error_code[] = {
//          error code,                    error description,
	       { AT_ERROR_UNKNOW,               (uint8_t *)&"ERROR_UNKNOW"                },
	       { AT_ERROR_UNKNOW_COMMAND,       (uint8_t *)&"ERROR_UNKNOW_COMMAND"        },
	       { AT_ERROR_LESS_ARGUMENTS,       (uint8_t *)&"ERROR_LESS_ARGUMENETS"       },
	       { AT_ERROR_MORE_ARGUMENETS,      (uint8_t *)&"ERROR_MORE_ARGUMENETS"       },
	       { AT_ERROR_INVALID_ARGUMENTS,    (uint8_t *)&"ERROR_INVALID_ARGUMENTS"     },
	       { AT_ERROR_NOT_SUPPORTED,        (uint8_t *)&"ERROR_NOT_SUPPORTED"         },
	       { AT_ERROR_OUT_OF_RANGE,         (uint8_t *)&"ERROR_OUT_OF_RANGE"          },
	       { AT_ERROR_RX_TIMEOUT,           (uint8_t *)&"ERROR_RX_TIMEOUT"            },
	       { AT_ERROR_RX_ERROR,             (uint8_t *)&"ERROR_RX_ERROR"              },
	       { AT_ERROR_TX_TIMEOUT,           (uint8_t *)&"ERROR_TX_TIMEOUT"            },
	       { AT_ERROR_TX_ERROR,             (uint8_t *)&"ERROR_TX_ERROR"              },
	       { AT_ERROR_RF_BUSY,              (uint8_t *)&"ERROR_RF_BUSY"               },
	       { AT_ERROR_TIMEOUT,              (uint8_t *)&"ERROR_TIMEOUT"               },
	       { AT_ERROR_NO_ARGUMENETS_NEEDED, (uint8_t *)&"ERROR_NO_ARGUMENETS_NEEDED"  },
	       { AT_ERROR_HAL_ERROR,            (uint8_t *)&"ERROR_HAL_ERROR"             },
	       { AT_ERROR_INVALID_HEX_FORMAT,   (uint8_t *)&"ERROR_INVALID_HEX_FORMAT"    },
	       { AT_ERROR_OUT_OF_ADDRESS,       (uint8_t *)&"ERROR_OUT_OF_ADDRESS"        },
	       { AT_ERROR_INVALID_NVM_TAG,      (uint8_t *)&"ERROR_INVALID_NVM_TAG"       },
	       { AT_ERROR_NVM_FULL,             (uint8_t *)&"ERROR_NVM_FULL"              },
	       { AT_ERROR_NVM_TAG_NOT_FOUND,    (uint8_t *)&"ERROR_NVM_TAG_NOT_FOUND"     },
	       { AT_ERROR_7SEG_ERROR,           (uint8_t *)&"ERROR_7SEG_ERROR"            },
	       { AT_ERROR_TMP75_ERROR,          (uint8_t *)&"ERROR_TMP75_ERROR"           },
	       { AT_ERROR_WAN_SEND,             (uint8_t *)&"ERROR_WAN_SEND"              },
	       { AT_ERROR_WAN_GETPARAM,         (uint8_t *)&"ERROR_WAN_GETPARAM"          },
	       { AT_ERROR_WAN_SETPARAM,         (uint8_t *)&"ERROR_WAN_SETPARAM"          },
	       { AT_ERROR_WAN_NON_JOINED,       (uint8_t *)&"ERROR_WAN_NON_JOINED"        },
	       { AT_ERROR_INVALID_ARGUMENTS,    0                                      }

};








#endif // __ERR_CODE_MAP_H__
