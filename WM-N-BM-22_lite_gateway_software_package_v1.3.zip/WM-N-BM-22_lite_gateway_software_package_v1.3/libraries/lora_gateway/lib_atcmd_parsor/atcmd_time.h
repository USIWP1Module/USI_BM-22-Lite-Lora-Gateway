
#ifndef __ATCMD_TIME_H__
#define __ATCMD_TIME_H__



#define GetTickCount get_tick_count



uint32_t get_tick_count( void );






#endif
