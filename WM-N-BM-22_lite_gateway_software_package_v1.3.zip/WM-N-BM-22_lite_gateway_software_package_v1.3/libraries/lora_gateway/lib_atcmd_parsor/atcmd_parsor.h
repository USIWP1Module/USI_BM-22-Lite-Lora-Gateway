#ifndef __ATCMD_PARSOR_H__
#define __ATCMD_PARSOR_H__

#include "atcmd_parsor_def.h"
#include "str_utl.h"



#if !defined( ATCMD_INTERNAL )

//extern uint32_t error_cmd_retry_count;
//extern int ReturnedOKs;
//extern int ReturnedERRORs;
//extern int LastErrorCode;

#endif


int  init_atcmd_parsor( void );
int reset_atcmd_parsor( atcmd_console_t *pconsole );
int  atcmd_add_cmd( ATCMD_PROCESS func, uint8_t *cmd_text );
int  atcmd_add_console( atcmd_console_t *pconsole );
void DumpBinary( uint8_t *caption, uint8_t *data, int size);
void DumpAtCmd( uint8_t *caption, uint8_t *data, int size);
int  is_possible_error_code( uint8_t *text );
int  ConvertErrorCode( uint8_t *text );

int  is_at_cmd_finished( atcmd_console_t *pconsole, uint8_t c );
void console_do_cmd_finished(  atcmd_console_t *pconsole );
void PushToBuffer( atcmd_console_t *pconsole, uint8_t c );
int  SplitArgs( uint8_t *data,  uint8_t *split_chars, uint8_t *args[], int args_size );
int  process_at_cmd( atcmd_console_t *pconsole );
int  WaitAtcmdDone(  atcmd_console_t *pconsole, uint32_t timeout );
int  PostAtCommand( atcmd_console_t *pconsole, uint8_t *at_cmd, int size, int delay_ms  );
int  SendAtCommand( atcmd_console_t *pconsole, uint8_t *at_cmd, int size, int timeout, int retry_cnt );
int InquiryAtCommand( atcmd_console_t *pconsole, uint8_t *at_cmd, int size, int timeout, int retry_cnt  );


#endif  // __ATCMD_PARSOR_H__
