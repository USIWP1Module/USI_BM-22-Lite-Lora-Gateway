#ifndef __SLGW_ACTIVITY_DB_H__
#define __SLGW_ACTIVITY_DB_H__

#include "slgw_lib.h"


#define MAX_RX_DB_NUMBER 50
#define MAX_DB_PKT_SIZE  128

typedef enum {
	PKT_GW_ULINK,
	PKT_GW_DLINK,
	PKT_APP_ULINK,
	PKT_APP_DLINK,
	PKT_TYPE_MAX,  /* for initiate array purpose */
}gw_pkt_type_t;


typedef struct {

	char payload[MAX_DB_PKT_SIZE];
	int index;
	int list_prev;
	int list_next;
	uint32_t dev_addr;
	int  payload_size;
	int pkt_cnt;
	int port;
	gw_pkt_type_t pkt_type;
	wiced_iso8601_time_t time_stamp;
	float freq_mhz;
	uint32_t datarate;
	uint8_t  coderate;
	uint8_t  bandwidth;
	wiced_bool_t is_ready;

}pkt_db_item_t;


typedef struct {

	pkt_db_item_t *data;
	pkt_db_item_t *top_item;
	pkt_db_item_t *last_item;

	int size;
	int length;
	int write_index;
	int read_index;

}pkt_db_t;







void slgw_activity_db_init( void );
void push_to_pkt_db( gw_pkt_type_t pkt_type, void *pkt_obj );
char *get_packet_type_style_text( int pkt_type );
void  push_gw_rxpkt_to_db( struct lgw_pkt_rx_s *pkt );
void  push_gw_txpkt_to_db( struct lgw_pkt_tx_s *pkt );


pkt_db_item_t *slgw_get_first_activity( void );
pkt_db_item_t *slgw_get_activity_by_index( int index );
int            slgw_get_activity_data_length( void );

#endif // __SLGW_ACTIVITY_DB_H__
