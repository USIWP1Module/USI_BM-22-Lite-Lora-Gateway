#include "wiced.h"

#include "activity_db.h"

#define MSG_DEBUG printf
#define MSG_ERROR printf
#define MSG_INFO printf


#define UNKNOW_STR "UNKNOW"

static pkt_db_item_t pkt_rxs[MAX_RX_DB_NUMBER];
static pkt_db_t pkt_db;


static pkt_db_t pkt_db = {
	.data = pkt_rxs,
	.size = MAX_RX_DB_NUMBER,
	.length = 0,
	.top_item = 0,
	.last_item = 0,
	.write_index = 0,
};


char *pkt_type_style_texts[] = {
		[PKT_GW_ULINK] = "<tt id=\"ulink\">U</tt>",
		[PKT_GW_DLINK] = "<tt id=\"dlink\">D</tt>",
		[PKT_APP_ULINK] = "<tt id=\"uplink\">u</tt>",
		[PKT_APP_DLINK] = "<tt id=\"dplink\">d</tt>",
};



static void  from_gw_txpkt(  pkt_db_item_t *db_item,  struct lgw_pkt_tx_s *pkt );
static void  from_gw_rxpkt(  pkt_db_item_t *db_item,  struct lgw_pkt_rx_s *pkt );
static void  from_dummy_pkt(  pkt_db_item_t *db_item  );


pkt_db_item_t *slgw_get_first_activity( void )
{
	return pkt_db.top_item;
}

pkt_db_item_t *slgw_get_activity_by_index( int index )
{
	return &pkt_rxs[index];
}

int slgw_get_activity_data_length( void )
{

	return pkt_db.length;
}

void slgw_activity_db_init( void )
{
	int i;

	for( i = 0; i < MAX_RX_DB_NUMBER; i++  ){
		pkt_rxs[i].list_next = -1;
		pkt_rxs[i].list_prev = -1;
		pkt_rxs[i].index = i;
		pkt_rxs[i].dev_addr = 0xFFFFFFFF;
		pkt_rxs[i].payload_size = 0;
		pkt_rxs[i].pkt_cnt = 0;
	}

	pkt_db.length = 0;
	pkt_db.size = 0;
	pkt_db.top_item = 0;
	pkt_db.last_item = 0;
	pkt_db.write_index = 0;

	MSG_DEBUG( "%s(): init done.\r\n", __FUNCTION__ );
}







static void  from_gw_txpkt(  pkt_db_item_t *db_item,  struct lgw_pkt_tx_s *pkt )
{
	int byte_index;
	uint8_t ctrl_bits;

	byte_index = 1;

	db_item->dev_addr = pkt->payload[byte_index++] & 0xFF;            // byte_1
	db_item->dev_addr |= (pkt->payload[byte_index++] & 0xFF) << 8;    // byte_2
	db_item->dev_addr |= (pkt->payload[byte_index++] & 0xFF) << 16;   // byte_3
	db_item->dev_addr |= (pkt->payload[byte_index++] & 0xFF) << 24;   // byte_4

    ctrl_bits = pkt->payload[byte_index++];   // byte_5

	if( ctrl_bits ){  }

	db_item->pkt_cnt = pkt->payload[byte_index++] & 0xFF;          // byte_6
    db_item->pkt_cnt |= (pkt->payload[byte_index++] & 0xFF) << 8;  // byte_7

    db_item->port = pkt->payload[byte_index++];  // byte_8
	//db_item->time_stamp = pkt->count_us;
    wiced_time_get_iso8601_time( &db_item->time_stamp );
	db_item->datarate = pkt->datarate;
	db_item->bandwidth = pkt->bandwidth;
	db_item->coderate = pkt->coderate;
	db_item->freq_mhz = (float)pkt->freq_hz / 1000000.0;
	db_item->payload_size = pkt->size;   /* record the payload length */
	if( pkt->size > MAX_DB_PKT_SIZE ) db_item->payload_size = MAX_DB_PKT_SIZE;
	memcpy(  (void *)&db_item->payload, (const char *)&pkt->payload, pkt->size );  /* record the content of payload */
}

static void  from_gw_rxpkt(  pkt_db_item_t *db_item,  struct lgw_pkt_rx_s *pkt )
{
	int byte_index;
	uint8_t ctrl_bits;

	byte_index = 1;

	db_item->dev_addr = pkt->payload[byte_index++] & 0xFF;            // byte_1
	db_item->dev_addr |= (pkt->payload[byte_index++] & 0xFF) << 8;    // byte_2
	db_item->dev_addr |= (pkt->payload[byte_index++] & 0xFF) << 16;   // byte_3
	db_item->dev_addr |= (pkt->payload[byte_index++] & 0xFF) << 24;   // byte_4

    ctrl_bits = pkt->payload[byte_index++];   // byte_5

	if( ctrl_bits ){  }

	db_item->pkt_cnt = pkt->payload[byte_index++] & 0xFF;          // byte_6
    db_item->pkt_cnt |= (pkt->payload[byte_index++] & 0xFF) << 8;  // byte_7

    db_item->port = pkt->payload[byte_index++];  // byte_8
    wiced_time_get_iso8601_time( &db_item->time_stamp );
	db_item->datarate = pkt->datarate;
	db_item->bandwidth = pkt->bandwidth;
	db_item->coderate = pkt->coderate;
	db_item->freq_mhz = (float)pkt->freq_hz / 1000000.0;
	db_item->payload_size = pkt->size;   /* record the payload length */
	if( pkt->size > MAX_DB_PKT_SIZE ) db_item->payload_size = MAX_DB_PKT_SIZE;
	memcpy(  (void *)&db_item->payload, (const char *)&pkt->payload, pkt->size );  /* record the content of payload */
}


static void  from_dummy_pkt(  pkt_db_item_t *db_item  )
{
	db_item->dev_addr = 0;
	db_item->pkt_cnt = 0;
    db_item->port = 0;
    wiced_time_get_iso8601_time( &db_item->time_stamp );
	db_item->datarate = 0;
	db_item->bandwidth = 0;
	db_item->coderate = 0;
	db_item->freq_mhz = 0;
	db_item->payload_size = 0;
	db_item->payload[0] = 0;
}



void push_to_pkt_db( gw_pkt_type_t pkt_type, void *pkt_obj )
{
	int write_index;
	int next_index;
	//int keep_payload_size;
	int i;

	write_index = pkt_db.write_index;
	next_index = (write_index + 1) % MAX_RX_DB_NUMBER;

	/* if db is full */
	if( next_index == pkt_db.read_index ){

		if(  pkt_db.last_item->index == write_index ){
		    MSG_DEBUG( "%s(): db full, must remove last one (%d)", __FUNCTION__,  pkt_db.last_item->index );
		    pkt_db.last_item->is_ready = WICED_FALSE;
		    i = pkt_db.last_item->list_prev;
		    pkt_db.last_item = &pkt_db.data[i];   /* move last index up */
		    pkt_db.last_item->list_next = -1;
		    MSG_DEBUG( ", new last one is (%d)\r\n", pkt_db.last_item->index );
		}

	    pkt_db.read_index = (pkt_db.read_index + 1) % MAX_RX_DB_NUMBER;  /* forward the read index */
	}

	pkt_db.data[write_index].pkt_type = pkt_type;

	switch( pkt_type ){
	case PKT_GW_DLINK:
	       from_gw_txpkt( &pkt_db.data[write_index], pkt_obj );
	       break;
	case PKT_GW_ULINK:
		   from_gw_rxpkt( &pkt_db.data[write_index], pkt_obj );
		   break;
	default:
		from_dummy_pkt( &pkt_db.data[write_index] );
		break;
	}

	pkt_db.write_index = next_index;   /* record the data index */

	if( pkt_db.top_item == 0 ){
		pkt_db.top_item = &pkt_db.data[write_index];
		pkt_db.last_item = &pkt_db.data[write_index];
	}else{
		pkt_db.data[write_index].list_next = pkt_db.top_item->index;   // move down the top one
		pkt_db.top_item->list_prev = write_index;  // insert new one at top
		pkt_db.top_item = &pkt_db.data[write_index];
		MSG_DEBUG( "%s(): new top item is at # %d\r\n", __FUNCTION__,  pkt_db.top_item->index );

	}

	pkt_db.data[write_index].is_ready = WICED_TRUE;

	if( pkt_db.length < MAX_RX_DB_NUMBER ) pkt_db.length++;   /* increase the length of the list */

	//dump_pkt_list( 0, 20 );

}


char *get_packet_type_style_text( int pkt_type )
{
	if( pkt_type >= PKT_TYPE_MAX ) return UNKNOW_STR;

	return pkt_type_style_texts[pkt_type];
}




#if 0
static void dump_pkt_list( int start_index,  int size )
{
	int i, n;
	int next_index;
	pkt_db_item_t *item;
	int index;
	int payload_offset;

	index = start_index;
	item = pkt_db.top_item;

	for( i = 0; i < size; i++ ){

		MSG_DEBUG( "(%d) %08X, %08X, %d, %d",  index, (unsigned int)item->data.count_us, (unsigned int)item->dev_addr, item->pkt_cnt, item->payload_size );
		payload_offset = item->payload_addr;
		for( n = 0; n < item->payload_size; n++ ) MSG_DEBUG( " %02X", item->data.payload[payload_offset + n] );
		MSG_DEBUG( "\r\n" );

		next_index = item->list_next;
		if( next_index < 0 || next_index >= MAX_RX_DB_NUMBER ) break;
		item = &pkt_db.data[next_index];

	}

}

#endif


