
#include <math.h>
#include "wiced.h"
#include "button_manager.h"
#include "thermistor.h"
#include "http_server.h"
#include "sntp.h"
#include "gedday.h"
#include "resources.h"
#include "wiced_resource.h"


#include "slgw_lib.h"

#include "LoRaMacCrypto.h"
#include "activity_db.h"
#include "lite_gw_web.h"
#include "lora_str_util.h"



/******************************************************
 *                    Constants
 ******************************************************/
//#define TEST_THE_WEB

#define MAX_HTTP_CLIENT_SOCKETS  10

#define MAX_NTP_ATTEMPTS                    (3)
#define BUTTON_WORKER_STACK_SIZE            ( 1024 )
#define BUTTON_WORKER_QUEUE_SIZE            ( 4 )

#define ULINK_SYMBOL "<tt id=\"ulink\">U</tt>"

#define ITEM_IP_START      "<p id=\"gw_ip\"> gateway IP address:  <input type=\"text\" name=gw_ip value=\""
#define ITEM_IP_END        "\"> </p>"
#define ITEM_ULINK_START   "<p id=\"index_texts\"> gateway Dlink port:  <input type=\"text\" name=gw_uport value=\""
#define ITEM_ULINK_END     "\"> </p>"
#define ITEM_DLINK_START   "<p id=\"index_texts\"> gateway Ulink port:  <input type=\"text\" name=gw_dip value=\""
#define ITEM_DLINK_END     "\"> </p>"



/******************************************************
 *                   Enumerations
 ******************************************************/





/******************************************************
 *                 Type Definitions
 ******************************************************/


/******************************************************
 *                    Structures
 ******************************************************/


/******************************************************
 *               Static Function Declarations
 ******************************************************/
static int32_t        process_gw_status_update       ( const char* url_path, const char* url_parameters, wiced_http_response_stream_t* stream, void* arg, wiced_http_message_body_t* http_data );
static int32_t        process_activity_update        ( const char* url_path, const char* url_parameters, wiced_http_response_stream_t* stream, void* arg, wiced_http_message_body_t* http_data );
static int32_t        process_gw_setting             ( const char* url_path, const char* url_parameters, wiced_http_response_stream_t* stream, void* arg, wiced_http_message_body_t* http_data );


/******************************************************
 *               Variable Definitions
 ******************************************************/

static wiced_http_server_t http_server;
static START_OF_HTTP_PAGE_DATABASE(web_pages)
    ROOT_HTTP_PAGE_REDIRECT("/lite_gw_web/index.html"),
    { "/lite_gw_web/index.html",         "text/html",                WICED_RESOURCE_URL_CONTENT,  .url_content.resource_data  = &resources_lite_gw_web_DIR_index_html, },
    { "/lite_gw_web/indexs.html",        "text/html",                WICED_RESOURCE_URL_CONTENT,  .url_content.resource_data  = &resources_lite_gw_web_DIR_indexs_html, },
    { "/lite_gw_web/banner.html",        "text/html",                WICED_RESOURCE_URL_CONTENT,  .url_content.resource_data  = &resources_lite_gw_web_DIR_banner_html, },
    { "/lite_gw_web/devices.html",       "text/html",                WICED_RESOURCE_URL_CONTENT,  .url_content.resource_data  = &resources_lite_gw_web_DIR_devices_html, },
    { "/lite_gw_web/gateway.html",       "text/html",                WICED_RESOURCE_URL_CONTENT,  .url_content.resource_data  = &resources_lite_gw_web_DIR_gateway_html, },
    { "/lite_gw_web/gateway_setup.html", "text/html",                WICED_RESOURCE_URL_CONTENT,  .url_content.resource_data  = &resources_lite_gw_web_DIR_gateway_setup_html, },
    { "/lite_gw_web/activity.html",      "text/html",                WICED_RESOURCE_URL_CONTENT,  .url_content.resource_data  = &resources_lite_gw_web_DIR_activity_html, },
    { "/lite_gw_web/applications.html",  "text/html",                WICED_RESOURCE_URL_CONTENT,  .url_content.resource_data  = &resources_lite_gw_web_DIR_applications_html, },
    { "/device_monitor.html",            "text/html",                WICED_RESOURCE_URL_CONTENT,  .url_content.resource_data  = &resources_lite_gw_web_DIR_device_monitor_html, },
    { "/gw_status_report.html",          "text/html",                WICED_DYNAMIC_URL_CONTENT,   .url_content.dynamic_data   = {process_gw_status_update, 0 }, },
    { "/gw_setup.html",                  "text/html",                WICED_DYNAMIC_URL_CONTENT,   .url_content.dynamic_data   = {process_gw_setting, 0 }, },
    { "/activity_update.html",           "text/html",                WICED_DYNAMIC_URL_CONTENT,   .url_content.dynamic_data   = {process_activity_update, 0 }, },
    { "/images/favicon.ico",             "image/vnd.microsoft.icon", WICED_RESOURCE_URL_CONTENT,  .url_content.resource_data  = &resources_lr_config_DIR_images_DIR_favicon_ico, },
    { "/scripts/general_ajax_script.js", "application/javascript",   WICED_RESOURCE_URL_CONTENT,  .url_content.resource_data  = &resources_lr_config_DIR_scripts_DIR_general_ajax_script_js, },
    { "/images/brcmlogo.png",            "image/png",                WICED_RESOURCE_URL_CONTENT,  .url_content.resource_data  = &resources_lr_config_DIR_images_DIR_brcmlogo_png, },
    { "/images/brcmlogo_line.png",       "image/png",                WICED_RESOURCE_URL_CONTENT,  .url_content.resource_data  = &resources_lr_config_DIR_images_DIR_brcmlogo_line_png, },
END_OF_HTTP_PAGE_DATABASE();



/* simple gateway static declaration */

static int activity_update_count = 0;



void init_lite_gw_web( void )
{



}

void start_lite_gw_web( void )
{

#if 0
	WPRINT_APP_INFO(( "synchronise the time by SNTP ...\r\n"));
     /* Start automatic time synchronisation and synchronise once every day. */
    sntp_start_auto_time_sync( 1 * DAYS );
#endif


    /* Start web server to display current temperature & setpoint */
    wiced_http_server_start( &http_server, 80,  MAX_HTTP_CLIENT_SOCKETS, web_pages, WICED_STA_INTERFACE, DEFAULT_URL_PROCESSOR_STACK_SIZE );

    /* Advertise webpage services using Gedday */
    gedday_init( WICED_STA_INTERFACE, "litegw" );
    gedday_add_service( "lite gateway web server", "_http._tcp.local", 80, 300, "" );

    WPRINT_APP_INFO(("this demonstrates a simple lora gateway with SM42.\r\n"));


    slgw_activity_db_init();



}





static int32_t process_gw_setting( const char* url_path, const char* url_parameters, wiced_http_response_stream_t* stream, void* arg, wiced_http_message_body_t* http_data )
{

	wiced_http_response_stream_write(stream, ITEM_IP_START,    sizeof(ITEM_IP_START) - 1 );
	wiced_http_response_stream_write(stream, "192.168.88.7",   sizeof("192.168.88.7") - 1 );
	wiced_http_response_stream_write(stream, ITEM_IP_END,      sizeof(ITEM_IP_END) - 1 );
	wiced_http_response_stream_write(stream, ITEM_ULINK_START, sizeof(ITEM_ULINK_START) - 1 );
	wiced_http_response_stream_write(stream, "1688",   sizeof("1688") - 1 );
	wiced_http_response_stream_write(stream, ITEM_ULINK_END,   sizeof(ITEM_ULINK_END) - 1 );
	wiced_http_response_stream_write(stream, ITEM_DLINK_START, sizeof(ITEM_DLINK_START) - 1 );
	wiced_http_response_stream_write(stream, "1688",   sizeof("1688") - 1 );
	wiced_http_response_stream_write(stream, ITEM_DLINK_END,   sizeof(ITEM_DLINK_END) - 1 );


   return 0;
}




static int32_t process_gw_status_update( const char* url_path, const char* url_parameters, wiced_http_response_stream_t* stream, void* arg, wiced_http_message_body_t* http_data )
{
    char  temp_char_buffer[16];
    int   temp_char_buffer_length;
    wiced_ip_address_t  ip;

    UNUSED_PARAMETER( url_path );
    UNUSED_PARAMETER( http_data );

    /* Write the time */
    wiced_http_response_stream_write_resource( stream, &resources_lite_gw_web_DIR_gateway_data_html_gw_status_lora );

    wiced_http_response_stream_write_resource( stream, &resources_lite_gw_web_DIR_gateway_data_html_gw_status_lora_band );
    temp_char_buffer_length = sprintf(temp_char_buffer, "EU868");
    wiced_http_response_stream_write(stream, temp_char_buffer, temp_char_buffer_length );

    wiced_http_response_stream_write_resource( stream, &resources_lite_gw_web_DIR_gateway_data_html_gw_status_lora_dr );
    temp_char_buffer_length = sprintf(temp_char_buffer, "DR0");
    wiced_http_response_stream_write(stream, temp_char_buffer, temp_char_buffer_length );

    wiced_http_response_stream_write_resource( stream, &resources_lite_gw_web_DIR_gateway_data_html_gw_status_lora_clients );
    temp_char_buffer_length = sprintf(temp_char_buffer, "0");
    wiced_http_response_stream_write(stream, temp_char_buffer, temp_char_buffer_length );

    wiced_http_response_stream_write_resource( stream, &resources_lite_gw_web_DIR_gateway_data_html_gw_status_lora_txcnts );
    temp_char_buffer_length = sprintf(temp_char_buffer, "0");
    wiced_http_response_stream_write(stream, temp_char_buffer, temp_char_buffer_length );

    wiced_http_response_stream_write_resource( stream, &resources_lite_gw_web_DIR_gateway_data_html_gw_status_lora_rxcnts );
    temp_char_buffer_length = sprintf(temp_char_buffer, "0");
    wiced_http_response_stream_write(stream, temp_char_buffer, temp_char_buffer_length );

    wiced_http_response_stream_write_resource( stream, &resources_lite_gw_web_DIR_gateway_data_html_gw_status_sta );
    wiced_http_response_stream_write_resource( stream, &resources_lite_gw_web_DIR_gateway_data_html_gw_status_sta_conn );

    temp_char_buffer_length = sprintf(temp_char_buffer, "%s", (wiced_network_is_up(WICED_STA_INTERFACE) ? "CONNECTED" : "DISCONNECTED"));
    wiced_http_response_stream_write(stream, temp_char_buffer, temp_char_buffer_length );

    wiced_http_response_stream_write_resource( stream, &resources_lite_gw_web_DIR_gateway_data_html_gw_status_sta_ip );

    wiced_ip_get_ipv4_address( WICED_STA_INTERFACE, &ip );
    temp_char_buffer_length = sprintf( temp_char_buffer, "%u.%u.%u.%u",
    		(unsigned int)((GET_IPV4_ADDRESS(ip) >> 24) & 0xFF),
            (unsigned int)((GET_IPV4_ADDRESS(ip) >> 16) & 0xFF),
            (unsigned int)((GET_IPV4_ADDRESS(ip) >>  8) & 0xFF),
            (unsigned int)((GET_IPV4_ADDRESS(ip) >>  0) & 0xFF)
    );
    wiced_http_response_stream_write(stream, temp_char_buffer, temp_char_buffer_length );

    wiced_http_response_stream_write_resource( stream, &resources_lite_gw_web_DIR_gateway_data_html_gw_status_sta_mask );

    wiced_ip_get_netmask( WICED_STA_INTERFACE, &ip );
    temp_char_buffer_length = sprintf( temp_char_buffer, "%u.%u.%u.%u",
    		(unsigned int)((GET_IPV4_ADDRESS(ip) >> 24) & 0xFF),
            (unsigned int)((GET_IPV4_ADDRESS(ip) >> 16) & 0xFF),
            (unsigned int)((GET_IPV4_ADDRESS(ip) >>  8) & 0xFF),
            (unsigned int)((GET_IPV4_ADDRESS(ip) >>  0) & 0xFF)
    );
    wiced_http_response_stream_write(stream, temp_char_buffer, temp_char_buffer_length );

    wiced_http_response_stream_write_resource( stream, &resources_lite_gw_web_DIR_gateway_data_html_gw_status_sta_gw );

    wiced_ip_get_gateway_address( WICED_STA_INTERFACE, &ip );
    temp_char_buffer_length = sprintf( temp_char_buffer, "%u.%u.%u.%u",
    		(unsigned int)((GET_IPV4_ADDRESS(ip) >> 24) & 0xFF),
            (unsigned int)((GET_IPV4_ADDRESS(ip) >> 16) & 0xFF),
            (unsigned int)((GET_IPV4_ADDRESS(ip) >>  8) & 0xFF),
            (unsigned int)((GET_IPV4_ADDRESS(ip) >>  0) & 0xFF)
    );
    wiced_http_response_stream_write(stream, temp_char_buffer, temp_char_buffer_length );

    wiced_http_response_stream_write_resource( stream, &resources_lite_gw_web_DIR_gateway_data_html_gw_status_ap );

    wiced_http_response_stream_write_resource( stream, &resources_lite_gw_web_DIR_gateway_data_html_gw_status_ap_ip );

    wiced_ip_get_ipv4_address( WICED_AP_INTERFACE, &ip );
    temp_char_buffer_length = sprintf( temp_char_buffer, "%u.%u.%u.%u",
    		(unsigned int)((GET_IPV4_ADDRESS(ip) >> 24) & 0xFF),
            (unsigned int)((GET_IPV4_ADDRESS(ip) >> 16) & 0xFF),
            (unsigned int)((GET_IPV4_ADDRESS(ip) >>  8) & 0xFF),
            (unsigned int)((GET_IPV4_ADDRESS(ip) >>  0) & 0xFF)
    );
    wiced_http_response_stream_write(stream, temp_char_buffer, temp_char_buffer_length );

    wiced_http_response_stream_write_resource( stream, &resources_lite_gw_web_DIR_gateway_data_html_gw_status_ap_mask );

    wiced_ip_get_netmask( WICED_AP_INTERFACE, &ip );
    temp_char_buffer_length = sprintf( temp_char_buffer, "%u.%u.%u.%u",
    		(unsigned int)((GET_IPV4_ADDRESS(ip) >> 24) & 0xFF),
            (unsigned int)((GET_IPV4_ADDRESS(ip) >> 16) & 0xFF),
            (unsigned int)((GET_IPV4_ADDRESS(ip) >>  8) & 0xFF),
            (unsigned int)((GET_IPV4_ADDRESS(ip) >>  0) & 0xFF)
    );
    wiced_http_response_stream_write(stream, temp_char_buffer, temp_char_buffer_length );

    wiced_http_response_stream_write_resource( stream, &resources_lite_gw_web_DIR_gateway_data_html_gw_status_ap_gw );

    wiced_ip_get_gateway_address( WICED_AP_INTERFACE, &ip );
    temp_char_buffer_length = sprintf( temp_char_buffer, "%u.%u.%u.%u",
    		(unsigned int)((GET_IPV4_ADDRESS(ip) >> 24) & 0xFF),
            (unsigned int)((GET_IPV4_ADDRESS(ip) >> 16) & 0xFF),
            (unsigned int)((GET_IPV4_ADDRESS(ip) >>  8) & 0xFF),
            (unsigned int)((GET_IPV4_ADDRESS(ip) >>  0) & 0xFF)
    );
    wiced_http_response_stream_write(stream, temp_char_buffer, temp_char_buffer_length );

    wiced_http_response_stream_write_resource( stream, &resources_lite_gw_web_DIR_gateway_data_html_gw_status_end );



    return 0;
}

static char web_char_buffer[128];


static int32_t process_activity_update( const char* url_path, const char* url_parameters, wiced_http_response_stream_t* stream, void* arg, wiced_http_message_body_t* http_data )
{
    volatile int temp_char_buffer_length;
    int   i;
    pkt_db_item_t *item;
	int n;
	int next_index;
	int list_length;


    UNUSED_PARAMETER( url_path );
    UNUSED_PARAMETER( http_data );

    temp_char_buffer_length = 0;

    item = slgw_get_first_activity();

    /* Write the time */
    //wiced_http_response_stream_write_resource( stream, &resources_lite_gw_web_DIR_activity_data_html_activity_eui );
    //wiced_http_response_stream_write_resource( stream, &resources_lite_gw_web_DIR_activity_data_html_activity_table_start );

    wiced_http_response_stream_write_resource( stream, &resources_lite_gw_web_DIR_activity_data_html_gw_act_start );


    list_length = slgw_get_activity_data_length();

#if defined(TEST_THE_WEB)
    list_length = activity_update_count;
#endif

    for( i = 0; i < list_length; i++ ){

    	if( item == 0 ) {
    		WPRINT_APP_INFO(( "no data to report on web\r\n" ));
    		break;
    	}

    	if( !item->is_ready ) {
    		WPRINT_APP_INFO(( "this item is not ready.\r\n" ));
    		break;
    	}

    	//payload_offset = item->payload_addr;
        wiced_http_response_stream_write_resource( stream, &resources_lite_gw_web_DIR_activity_data_html_gw_act_table_start );

#if defined(TEST_THE_WEB)

        /* show packet type */
        temp_char_buffer_length = sprintf(web_char_buffer, "%s", ULINK_SYMBOL);
        wiced_http_response_stream_write(stream, web_char_buffer, temp_char_buffer_length );
        wiced_http_response_stream_write_resource( stream, &resources_lite_gw_web_DIR_activity_data_html_gw_act_pkt_type );

        /* show the happening time */
        temp_char_buffer_length = sprintf(web_char_buffer, "10:00:30");
        wiced_http_response_stream_write(stream, web_char_buffer, temp_char_buffer_length );
        wiced_http_response_stream_write_resource( stream, &resources_lite_gw_web_DIR_activity_data_html_gw_act_time );

        /* show the frequency */
        temp_char_buffer_length = sprintf(web_char_buffer, "868.3");
        wiced_http_response_stream_write(stream, web_char_buffer, temp_char_buffer_length );
        wiced_http_response_stream_write_resource( stream, &resources_lite_gw_web_DIR_activity_data_html_gw_act_freq );

        /* show the CR */
        temp_char_buffer_length = sprintf(web_char_buffer, "4/5");
        wiced_http_response_stream_write(stream, web_char_buffer, temp_char_buffer_length );
        wiced_http_response_stream_write_resource( stream, &resources_lite_gw_web_DIR_activity_data_html_gw_act_cr );

        /* show the SF */
        temp_char_buffer_length = sprintf(web_char_buffer, "9");
        wiced_http_response_stream_write(stream, web_char_buffer, temp_char_buffer_length );
        wiced_http_response_stream_write_resource( stream, &resources_lite_gw_web_DIR_activity_data_html_gw_act_sf );

        /* show the bandwidth */
        temp_char_buffer_length = sprintf(web_char_buffer, "125");
        wiced_http_response_stream_write(stream, web_char_buffer, temp_char_buffer_length );
        wiced_http_response_stream_write_resource( stream, &resources_lite_gw_web_DIR_activity_data_html_gw_act_bw );

        /* show the sequence of the packet */
        temp_char_buffer_length = sprintf(web_char_buffer, "1");
        wiced_http_response_stream_write(stream, web_char_buffer, temp_char_buffer_length );
        wiced_http_response_stream_write_resource( stream, &resources_lite_gw_web_DIR_activity_data_html_gw_act_seq );

        /* show device address */
        temp_char_buffer_length = sprintf(web_char_buffer, "11 22 33 44");
        wiced_http_response_stream_write(stream, web_char_buffer, temp_char_buffer_length );
        wiced_http_response_stream_write_resource( stream, &resources_lite_gw_web_DIR_activity_data_html_gw_act_addr );

        /* show the length of payload */
        temp_char_buffer_length = sprintf(web_char_buffer, "23");
        wiced_http_response_stream_write(stream, web_char_buffer, temp_char_buffer_length );
        wiced_http_response_stream_write_resource( stream, &resources_lite_gw_web_DIR_activity_data_html_gw_act_size );

        /* show content of payload */
        temp_char_buffer_length = sprintf(web_char_buffer, "00 11 22 33 44 55 66 77 88 99 00 AA BB CC DD EE FF 00 11 22 33 44 55 66");
        wiced_http_response_stream_write(stream, web_char_buffer, temp_char_buffer_length );
        wiced_http_response_stream_write_resource( stream, &resources_lite_gw_web_DIR_activity_data_html_gw_act_payload );

#else

        /* show packet type */
        temp_char_buffer_length = sprintf(web_char_buffer, "%s", get_packet_type_style_text(item->pkt_type) );
        wiced_http_response_stream_write(stream, web_char_buffer, temp_char_buffer_length );
        wiced_http_response_stream_write_resource( stream, &resources_lite_gw_web_DIR_activity_data_html_gw_act_pkt_type );

        /* show the happening time */
        memcpy( web_char_buffer, (const void *)item->time_stamp.hour, 8 );  /* because hh:mm:ss total is 8 bytes */
        wiced_http_response_stream_write(stream, web_char_buffer, 8 );
        wiced_http_response_stream_write_resource( stream, &resources_lite_gw_web_DIR_activity_data_html_gw_act_time );

        /* show the frequency */
        temp_char_buffer_length = sprintf(web_char_buffer, "%.1f", item->freq_mhz );
        wiced_http_response_stream_write(stream, web_char_buffer, temp_char_buffer_length );
        wiced_http_response_stream_write_resource( stream, &resources_lite_gw_web_DIR_activity_data_html_gw_act_freq );

        /* show the CR */
        temp_char_buffer_length = sprintf(web_char_buffer, "%s", get_coderate_text(item->coderate) );
        wiced_http_response_stream_write(stream, web_char_buffer, temp_char_buffer_length );
        wiced_http_response_stream_write_resource( stream, &resources_lite_gw_web_DIR_activity_data_html_gw_act_cr );

        /* show the SF */
        temp_char_buffer_length = sprintf(web_char_buffer, "%ld", item->datarate  );
        wiced_http_response_stream_write(stream, web_char_buffer, temp_char_buffer_length );
        wiced_http_response_stream_write_resource( stream, &resources_lite_gw_web_DIR_activity_data_html_gw_act_sf );

        /* show the bandwidth */
        temp_char_buffer_length = sprintf(web_char_buffer, "%s", get_bandwidth_text(item->bandwidth));
        wiced_http_response_stream_write(stream, web_char_buffer, temp_char_buffer_length );
        wiced_http_response_stream_write_resource( stream, &resources_lite_gw_web_DIR_activity_data_html_gw_act_bw );

        /* show the sequence of the packet */
        temp_char_buffer_length = sprintf(web_char_buffer, "%d", item->pkt_cnt );
        wiced_http_response_stream_write(stream, web_char_buffer, temp_char_buffer_length );
        wiced_http_response_stream_write_resource( stream, &resources_lite_gw_web_DIR_activity_data_html_gw_act_seq );

        /* show device address */
        temp_char_buffer_length = sprintf(web_char_buffer, "%08lX", item->dev_addr );
        wiced_http_response_stream_write(stream, web_char_buffer, temp_char_buffer_length );
        wiced_http_response_stream_write_resource( stream, &resources_lite_gw_web_DIR_activity_data_html_gw_act_addr );

        /* show the length of payload */
        temp_char_buffer_length = sprintf(web_char_buffer, "%d", item->payload_size);
        wiced_http_response_stream_write(stream, web_char_buffer, temp_char_buffer_length );
        wiced_http_response_stream_write_resource( stream, &resources_lite_gw_web_DIR_activity_data_html_gw_act_size );

        /* show content of payload */
        temp_char_buffer_length = 0;
        for( n = 0; n < item->payload_size; n++ ) temp_char_buffer_length += sprintf( &web_char_buffer[temp_char_buffer_length], " %02X", item->payload[n] & 0xFF );
        web_char_buffer[temp_char_buffer_length] = 0;
        wiced_http_response_stream_write(stream, web_char_buffer, temp_char_buffer_length );
        wiced_http_response_stream_write_resource( stream, &resources_lite_gw_web_DIR_activity_data_html_gw_act_payload );
#endif


		next_index = item->list_next;
		if( next_index < 0 || next_index >= MAX_RX_DB_NUMBER ) break;
		item =  slgw_get_activity_by_index(next_index);

    }


    wiced_http_response_stream_write_resource( stream, &resources_lite_gw_web_DIR_activity_data_html_gw_act_table_end );



    WPRINT_APP_INFO(( "activities = %d\r\n", activity_update_count  ));
    activity_update_count++;


    return 0;
}





