#ifndef __USI_LORA_AT_HOST_H__
#define __USI_LORA_AT_HOST_H__


typedef void (*lrm_msg_handler_t)( const char *fmt, ... );


#include "loragw_hal.h"
#include "atcmd_parsor.h"



#define LRWAN_VERSION_SPEC  0x010001
//#define FW_VERSION_SPEC     0x0300
#define FW_VERSION_SPEC     0x0209


typedef enum {

	DR0,
	DR1,
	DR2,
	DR3,
	DR4,
	DR5,
	DR6,
	DR7,
	DR8,
	DR9,
	DR10,
	DR11,

}lrm_dr_type_t;



/*!
 * LoRaMAC frame control field definition (FCtrl)
 *
 * LoRaWAN Specification V1.0.1, chapter 4.3.1
 */
typedef union uLoRaMacFrameCtrl
{
    /*!
     * Byte-access to the bits
     */
    uint8_t Value;
    /*!
     * Structure containing single access to bits
     */
    struct sCtrlBits
    {
        /*!
         * Frame options length
         */
        uint8_t FOptsLen        : 4;
        /*!
         * Frame pending bit
         */
        uint8_t FPending        : 1;
        /*!
         * Message acknowledge bit
         */
        uint8_t Ack             : 1;
        /*!
         * ADR acknowledgment request bit
         */
        uint8_t AdrAckReq       : 1;
        /*!
         * ADR control in frame header
         */
        uint8_t Adr             : 1;
    }Bits;

}LoRaMacFrameCtrl_t;


/*!
 * LoRaMAC header field definition (MHDR field)
 *
 * LoRaWAN Specification V1.0.1, chapter 4.2
 */
typedef union uLoRaMacHeader
{
    /*!
     * Byte-access to the bits
     */
    uint8_t Value;
    /*!
     * Structure containing single access to header bits
     */
    struct sHdrBits
    {
        /*!
         * Major version
         */
        uint8_t Major           : 2;
        /*!
         * RFU
         */
        uint8_t RFU             : 3;
        /*!
         * Message type
         */
        uint8_t MType           : 3;
    }Bits;

}LoRaMacHeader_t;


/* the default module configuration for the gateway receivers */
#if 0

#define DEFAULT_RECEIVER_OP_MODE       LRM_RX_MODE   /* the modem's operation mode  */
#define DEFAULT_RECEIVER_DR            (DR3 << 24) | (LRM_SF_9 << 16) | (LRM_BW_125K << 8) | LRM_CR_4_5  /* since the op_mode is not LoraWAN, here must set the data rate in detail */
#define DEFAULT_RECEIVER_POWER         20            /* it is the TX power if used to transmit data  */
#define DEFAULT_RECEIVER_IQ_INVERTED   0             /* it is the TX power if used to transmit data  */

#else

#define DEFAULT_RECEIVER_OP_MODE       LRM_FGW_MODE  /* the modem's operation mode  */
#define DEFAULT_RECEIVER_DR            (DR3 << 24) | (LRM_SF_9 << 16) | (LRM_BW_125K << 8) | LRM_CR_4_5
#define DEFAULT_RECEIVER_JOIN_TYPE     0             /* APB join mode */
#define DEFAULT_RECEIVER_CLASS         2             /* LoraWAN class-C */
#define DEFAULT_RECEIVER_BAND          0             /* EU868 */
#define DEFAULT_RECEIVER_DC            0             /* disable ducty-cycle */
#define DEFAULT_RECEIVER_RX2DR         3             /* the data rate of RX2: DR3 (SF9, BW125) */
#define DEFAULT_RECEIVER_RX2DT         2000          /* the delay ms of rx2 window: 2000ms */
#define DEFAULT_RECEIVER_RX1DT         1000          /* the delay ms of rx1 window: 1000ms (used for join) */
#define DEFAULT_RECEIVER_POWER         20            /* it is the TX power for the TX RF chain */
#define DEFAULT_RECEIVER_IQ_INVERTED   1             /* LoraWAN sends packet with inverted-iq */

#endif

/* the default module configuration for the gateway transmitters */
#define DEFAULT_TRANSMITTER_OP_MODE       LRM_WLAN_MODE   /* the modem's operation mode  */
#define DEFAULT_TRANSMITTER_DR            (DR3 << 24) | (LRM_SF_9 << 16) | (LRM_BW_125K << 8) | LRM_CR_4_5
#define DEFAULT_TRANSMITTER_JOIN_TYPE     0         /* APB join mode */
#define DEFAULT_TRANSMITTER_CLASS         2         /* LoraWAN class-C */
#define DEFAULT_TRANSMITTER_BAND          0         /* EU868 */
#define DEFAULT_TRANSMITTER_DC            0         /* disable ducty-cycle */
#define DEFAULT_TRANSMITTER_RX2DR         3         /* the data rate of RX2: DR3 (SF9, BW125) */
#define DEFAULT_TRANSMITTER_RX2DT         2000      /* the delay ms of rx2 window: 2000ms */
#define DEFAULT_TRANSMITTER_RX1DT         1000      /* the delay ms of rx1 window: 1000ms (used for join) */
#define DEFAULT_TRANSMITTER_POWER         20        /* it is the TX power for the TX RF chain */
#define DEFAULT_TRANSMITTER_IQ_INVERTED   1         /* LoraWAN sends packet with inverted-iq */





typedef int (*LRM_RX_DONE_CALLBACK)( void *lrm_conf, uint8_t *payload, int size, int rssi, int snr, int time_stamp_ms );


typedef struct {

	int op_mode;
	int power_dbm;
	int join_type;
    int class;
    int band;
    int dr;        /* dr = LoraWAN DR if in modem mode, dr = sf(23-16) | bw(15-8) | cr(7-0) not in modem mode */
    int duty_cycle;
    int rx1_delay_time;
    int rx2_dr;
    int rx2_delay_time;
    int inverted_iq;
    int status;

    LRM_RX_DONE_CALLBACK rx_done_callback;

}lrm_mod_conf_t;



typedef struct {

	uint8_t chain_no;
    char initiated;                      /* indicates if gateway initiated. */
	struct lgw_conf_rxrf_s rf_conf;      /* RF configuration */
	atcmd_console_t  cmd_console;        /* command interface context */

	lrm_mod_conf_t *pmod_conf;
	wiced_gpio_t   sync_gpio;   /* Used to synchronize the TX/RX timing, set -1 if it is no used. */



}lrm_conf_t;


typedef enum {

	LRM_HSI_16M,
	LRM_MSI_4M,
	LRM_PLL_32M,

}lrm_sys_clock_t;


typedef enum {

	LRM_IDLE_MODE = 0,
	LRM_CW_MODE,
	LRM_CTX_MODE,
	LRM_CRX_MODE,
	LRM_TX_MODE,
	LRM_RX_MODE,
	LRM_WLAN_MODE,
	LRM_SGW_MODE = 8,
	LRM_FGW_MODE = 9,

}lrm_op_mode_t;


typedef enum {
	LRM_BW_125K = 0,
	LRM_BW_250K,
	LRM_BW_500K,
	LRM_BW_MAX,   /* for initate array size */
}lrm_bw_t;


typedef enum {
	LRM_SF_6 = 6,
	LRM_SF_7,
	LRM_SF_8,
	LRM_SF_9,
	LRM_SF_10,
	LRM_SF_11,
	LRM_SF_12,
}lrm_sf_t;

typedef enum {
	LRM_CR_4_5 = 1,
	LRM_CR_4_6,
	LRM_CR_4_7,
	LRM_CR_4_8,
	LRM_CR_MAX,  /* for initate array size */
}lrm_cr_t;





int lrm_init( lrm_conf_t *plrm_conf );
int lrm_reset_modem( lrm_conf_t *plrm_conf  );
int lrm_set_op_modem( lrm_conf_t *plrm_conf, int mode  );
int lrm_set_band( lrm_conf_t *plrm_conf, int band );
int lrm_set_dr( lrm_conf_t *plrm_conf, int dr );
int lrm_set_rx2dr( lrm_conf_t *plrm_conf, int dr );
int lrm_set_rx1_delay_time( lrm_conf_t *plrm_conf, int delay_ms );
int lrm_set_rx2_delay_time( lrm_conf_t *plrm_conf, int delay_ms );
int lrm_set_class( lrm_conf_t *plrm_conf, int class  );
int lrm_set_duty_cycle( lrm_conf_t *plrm_conf, int duty_cycle );
int lrm_set_rx2_freq( lrm_conf_t *plrm_conf, int freq_hz );
int lrm_set_p2p_freq( lrm_conf_t *plrm_conf, int freq_hz );
int lrm_join( lrm_conf_t *plrm_conf, int mode  );
int lrm_phy_send( atcmd_console_t *pconsole, uint8_t *payload, int size, int time_stamp_ms );
int lrm_send( lrm_conf_t *plrm_conf, int app_port, uint8_t *payload, int size, int force_ack );
int lrm_rx_callback( lrm_conf_t *plrm_conf );

int lrm_set_rf( lrm_conf_t *plrm_conf, int power_dbm, uint32_t freq_hz, uint8_t sf, uint8_t bw, uint8_t cr, uint8_t crc_on, uint8_t preamble, uint8_t inverted_iq  );
int lrm_set_transceiver( lrm_conf_t *plrm_conf, int power_dbm, uint32_t freq_hz, uint32_t dr, uint8_t crc_on, uint8_t preamble, uint8_t inverted_iq  );

int lrm_get_uart_rate( lrm_conf_t *plrm_conf, int *rate  );
int lrm_setup_modem( lrm_conf_t *plrm_conf, lrm_msg_handler_t msg_handler );

int lrm_set_uart_rate( lrm_conf_t *plrm_conf, int rate );
int lrm_detect_uart_baud( lrm_conf_t *plrm_conf, uint32_t test_rate_list[], int test_rate_count  );
int lrm_factory_reset( lrm_conf_t *plrm_conf );
int lrm_reset( lrm_conf_t *plrm_conf );
int lrm_set_uart_rate( lrm_conf_t *plrm_conf, int rate );
int lrm_update_dct( lrm_conf_t *plrm_conf, wiced_bool_t factory_reset );
int lrm_is_console_ready( lrm_conf_t *plrm_conf );

int lrm_get_versions( lrm_conf_t *plrm_conf, uint32_t *lrwan_ver, uint32_t *fw_ver  );
int lrm_set_system_clock( lrm_conf_t *plrm_conf, int clock_mode  );

int lrm_set_ioe( lrm_conf_t *plrm_conf, int tx_io,  int rx_io );

#endif // __USI_LORA_AT_HOST_H__
